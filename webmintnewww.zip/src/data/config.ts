import { PricingTier, ServiceDetail, PortfolioItem, TeamMember } from '../types';

export const BRAND_CONFIG = {
  name: 'WebMint',
  tagline: 'Modern websites and practical automations built for business growth.',
  positioningHeadline: 'Your business doesn’t need “just a website.” It needs the right digital system.',
  positioningSubheadline: 'WebMint helps businesses understand what will actually move them forward—then builds fast, modern websites and smart automations that are made around their goals.',
  contactEmail: 'webmint0001@gmail.com',
  phoneNumber: '+91 70153-00962',
  phoneRaw: '+917015300962',
  whatsappUrl: 'https://wa.me/917015300962',
  calendlyUrl: 'https://calendly.com/lakshit70153',
  instagramHandle: '@webmintt',
  instagramUrl: 'https://www.instagram.com/webmintt/?hl=en',
  primaryLocation: 'India (Serving Indian & Global Clients)',
  consultationDuration: '25-30 Mins (Free & No-Pressure)',
  currency: 'INR',
  currencySymbol: '₹',
};

export const PRICING_PACKAGES: PricingTier[] = [
  {
    id: 'starter',
    name: 'Starter Website',
    priceINR: '₹11,500',
    priceNote: 'Starting price • Scope confirmed after consultation',
    tagline: 'For businesses needing a focused, professional online presence.',
    bestFor: 'Cafés, local services, solo consultants, and new businesses establishing their first high-trust digital footprint.',
    included: [
      'Clean, custom single-to-multi section responsive architecture',
      'Purpose-built typography, color styling & mobile-first layout',
      'Direct contact, WhatsApp, or lead enquiry trigger flow',
      'Foundational on-page SEO setup & meta configuration',
      'High-performance, lightweight code (Fast load times)',
      '1-on-1 handoff with scope review & setup guidance'
    ],
    scopeNote: 'Final scope, exact page count, and custom features are confirmed during your free consultation.',
    ctaText: 'Book a Free Consultation',
    isPopular: false,
  },
  {
    id: 'growth',
    name: 'Growth Website',
    priceINR: '₹17,500',
    priceNote: 'Starting price • Scope confirmed after consultation',
    tagline: 'For businesses that need a more complete website and stronger lead-generation flow.',
    bestFor: 'Growing service businesses, fitness centers, regional agencies, and brands requiring multi-page depth & structured lead capture.',
    included: [
      'Multi-page responsive website (Home, Services, About, Work, Contact)',
      'Structured conversion flows tailored to customer decision journeys',
      'Interactive enquiry forms & booking/appointment integration',
      'Speed optimization & clean semantic React architecture',
      'Social proof & portfolio display layouts',
      'Search engine friendly structure & social share previews',
      'Post-launch walkthrough & 14-day initial support window'
    ],
    scopeNote: 'Final scope, integrations, and content structure are confirmed during your free consultation.',
    ctaText: 'Book a Free Consultation',
    isPopular: true,
  },
  {
    id: 'premium',
    name: 'Premium Website',
    priceINR: '₹22,999',
    priceNote: 'Starting price • Scope confirmed after consultation',
    tagline: 'For businesses requiring a more polished, custom, or comprehensive web presence.',
    bestFor: 'Established businesses, funded startups, and companies needing refined branding, bespoke animations, or tailored workflow integrations.',
    included: [
      'Custom React-driven interactive frontend with refined micro-interactions',
      'Bespoke page layouts crafted for high-ticket trust and conversion',
      'Advanced lead capture, CRM notifications or webhook routing',
      'Deep performance tuning & core web vitals optimization',
      'Custom analytics events & conversion tracking setup',
      'Dynamic content sections & tailored client presentation showcase',
      'Dedicated launch assistance & priority onboarding'
    ],
    scopeNote: 'Final scope, third-party services, and custom integrations are confirmed during your free consultation.',
    ctaText: 'Book a Free Consultation',
    isPopular: false,
  },
];

export const SERVICES_LIST: ServiceDetail[] = [
  {
    id: 'web-dev',
    title: 'Website Development',
    subtitle: 'Modern, fast, and purpose-built for business credibility',
    shortDesc: 'Modern, fast, responsive websites built around how customers discover, trust, and contact a business.',
    iconName: 'Globe',
    badge: 'Core Capability',
    pageId: 'web-dev',
    capabilities: [
      {
        title: 'Strategy & Page Structure',
        description: 'We organize your content around customer decision-making, ensuring every section builds trust and answers key questions.'
      },
      {
        title: 'UI/UX Design & Typography',
        description: 'Clean visual hierarchies, elegant type pairings, and restrained aesthetics that elevate your brand without distraction.'
      },
      {
        title: 'Responsive & React Web Development',
        description: 'Modern, fluid codebases that render seamlessly across smartphones, tablets, laptops, and ultra-wide screens.'
      },
      {
        title: 'SEO-Ready Foundations',
        description: 'Semantic HTML markup, meta tags, Open Graph previews, and fast rendering that give search engines clear signals.'
      },
      {
        title: 'Performance & Fast Loading',
        description: 'Lightweight asset delivery and zero bloat so your visitors never abandon your page waiting for it to load.'
      },
      {
        title: 'Lead & Contact Flows',
        description: 'Frictionless enquiry forms, WhatsApp connectors, calendar bookings, and direct action triggers.'
      }
    ],
    whatToExpect: [
      'A thorough discovery conversation before any design starts',
      'Clean, accessible layouts that feel natural on mobile devices',
      'Transparent explanations of every recommendation made',
      'Clean handover with guidance on how to manage your content'
    ],
    whatWeAvoid: [
      'No rigid, heavy templates loaded with unnecessary plugins',
      'No false promises of overnight #1 search rankings',
      'No bloated page weights that stall on standard 4G mobile connections',
      'No technical jargon used to justify unnecessary add-ons'
    ]
  },
  {
    id: 'automation',
    title: 'Workflow Automation',
    subtitle: 'Practical time-saving systems that eliminate repetitive tasks',
    shortDesc: 'Reduce repetitive work and create smoother internal processes using practical automation.',
    iconName: 'Cpu',
    badge: 'Operations & Growth',
    pageId: 'automation',
    capabilities: [
      {
        title: 'Lead Capture & Follow-up Workflows',
        description: 'Instantly route inquiries from web forms into your inbox, Slack, or Google Sheets with automated acknowledgment emails.'
      },
      {
        title: 'Form-to-CRM & Notification Flows',
        description: 'Keep your team synchronized in real-time when new prospective clients request quotes or consultations.'
      },
      {
        title: 'Booking & Inquiry Routing',
        description: 'Connect appointment tools with automatic calendar blocking, reminder pings, and intake questionnaires.'
      },
      {
        title: 'Repetitive Operational Tasks',
        description: 'Automate data collection, invoice logging, status updates, and customer record syncs across your existing tools.'
      },
      {
        title: 'AI-Assisted Workflows (Where Useful)',
        description: 'Practical AI categorization, auto-summarization, or draft responses where they genuinely save time without hallucinating.'
      }
    ],
    whatToExpect: [
      'Step 1 is always mapping out your real daily workflow first',
      'Reliable, lightweight integrations that do not break unexpectedly',
      'Focus on tangible time saved per week rather than theoretical complexity',
      'Clear documentation so your team knows how the automations function'
    ],
    whatWeAvoid: [
      'No complex enterprise software when a simple zap or webhook does the job',
      'No forced "AI chatbots" that frustrate real paying customers',
      'No fragile automations built without error handling or fallback alerts',
      'No monthly retainer traps for tasks that can be automated once and run smoothly'
    ]
  },
  {
    id: 'consultation',
    title: 'Digital Consultation',
    subtitle: 'Honest, business-first guidance before you invest',
    shortDesc: 'A clear, no-pressure conversation to determine whether a website, automation, or another next step makes sense.',
    iconName: 'MessageSquareCheck',
    badge: 'Zero Commitment',
    pageId: 'contact',
    capabilities: [
      {
        title: 'Goal & Operations Audit',
        description: 'We listen to how your business currently attracts clients and where manual bottlenecks occur.'
      },
      {
        title: 'Website vs Automation Assessment',
        description: 'We tell you candidly whether your next best move is an improved website, an operational automation, or neither.'
      },
      {
        title: 'Realistic Scope & Roadmap',
        description: 'A realistic estimate of requirements, timelines, and priorities without high-pressure sales tactics.'
      },
      {
        title: 'Objective Second Opinion',
        description: 'Have an existing proposal or struggling site? We will give you an honest technical and design assessment.'
      }
    ],
    whatToExpect: [
      'A relaxed 25-minute video or audio call focused on your business',
      'Plain English explanations without developer acronyms',
      'Honest feedback if building something new is not in your current best interest',
      'Actionable notes you can use regardless of whether you work with us'
    ],
    whatWeAvoid: [
      'No aggressive sales scripts or fake countdown timers',
      'No pushing features or packages that don’t align with your goals',
      'No technical commodity gatekeeping'
    ]
  }
];

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'artisan-cafe',
    title: 'Specialty Roastery & Café Digital Experience',
    category: 'Website',
    clientType: 'Hospitality & Food Service',
    summary: 'A warm, mobile-first web presence showcasing seasonal menus, location timings, and direct WhatsApp table bookings for local patrons.',
    deliverables: ['Custom Mobile Menu', 'Google Maps & Hours Sync', 'WhatsApp Reservation Trigger', 'Fast Image Loading'],
    tags: ['React', 'Mobile-First', 'Local SEO', 'Hospitality'],
    isPlaceholder: true,
    gradientTheme: 'from-[#0B3B39] to-[#0A192F]'
  },
  {
    id: 'fitness-onboarding',
    title: 'Boutique Fitness Studio Onboarding & Member Flow',
    category: 'Full Digital System',
    clientType: 'Health & Wellness',
    summary: 'High-converting class schedule showcase combined with an automated trial-pass booking flow connected to Google Calendar and SMS confirmations.',
    deliverables: ['Class Schedule Hub', 'Trial Pass Booking Flow', 'Automated Lead Notification', 'Member FAQ Section'],
    tags: ['Website + Automation', 'Lead Flow', 'Fitness', 'Calendar Sync'],
    isPlaceholder: true,
    gradientTheme: 'from-[#0F172A] to-[#134E4A]'
  },
  {
    id: 'consulting-practice',
    title: 'Advisory & Legal Practice Professional Hub',
    category: 'Website',
    clientType: 'Professional Services',
    summary: 'A refined, high-trust digital storefront for a boutique advisory firm featuring structured service breakdowns and confidential enquiry intake.',
    deliverables: ['Editorial Typography', 'Confidential Consultation Form', 'Service Depth Architecture', 'Zero Bloat'],
    tags: ['Trust Design', 'Editorial', 'Lead Intake', 'B2B'],
    isPlaceholder: true,
    gradientTheme: 'from-[#1E293B] to-[#0A192F]'
  },
  {
    id: 'agency-lead-routing',
    title: 'Client Intake & Automated Proposal Workflow',
    category: 'Automation',
    clientType: 'Creative Agency / B2B',
    summary: 'A streamlined multi-step intake form that automatically categorizes incoming client requests, generates a summary card in Slack, and creates a project folder in Google Drive.',
    deliverables: ['Custom Web Form', 'Slack Notification Hook', 'Google Drive Provisioning', 'Instant Autoresponder'],
    tags: ['Workflow Automation', 'CRM Sync', 'Operations', 'Productivity'],
    isPlaceholder: true,
    gradientTheme: 'from-[#064E3B] to-[#0F172A]'
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    name: 'Lakshit',
    role: 'Co-Founder • Strategy & Content',
    highlight: 'Experience working with a 250K+ subscriber channel',
    bio: 'Focuses on understanding the customer narrative, clear messaging, and ensuring every digital asset aligns with real audience behavior.',
    expertise: ['Audience Psychology', 'Content Strategy', 'Brand Clarity']
  },
  {
    name: 'Nikhil',
    role: 'Co-Founder • Growth & Analytics',
    highlight: 'Experience working with a 3M+ subscriber channel',
    bio: 'Brings data-driven clarity to digital projects, focusing on conversion friction points, user journeys, and operational efficiency.',
    expertise: ['Growth Analysis', 'Workflow Optimization', 'Performance Funnels']
  },
  {
    name: 'Arnav',
    role: 'Co-Founder • Engineering & Architecture',
    highlight: 'IIIT Student • Modern Systems & Automation',
    bio: 'Specializes in robust React web engineering, API integrations, and practical automations that run reliably without technical overhead.',
    expertise: ['React & Web Standards', 'API & Webhook Integrations', 'System Architecture']
  }
];

export const CORE_VALUES = [
  {
    title: 'Listen before building',
    desc: 'We start by understanding your customer journey, daily operations, and real growth bottlenecks before proposing any code.'
  },
  {
    title: 'Recommend what is useful',
    desc: 'If a simple WhatsApp link or standard workflow will solve your problem, we will never push an expensive web application.'
  },
  {
    title: 'Build with care',
    desc: 'Every layout is responsive, every script is lightweight, and every automation is tested for real-world edge cases.'
  },
  {
    title: 'Communicate clearly',
    desc: 'No technical jargon used to disguise commodity features. We explain what we build and why in plain, honest language.'
  },
  {
    title: 'Keep improving',
    desc: 'We build digital systems that are clean, modular, and ready to evolve as your business scales.'
  }
];

export const WHY_WEBMINT_POINTS = [
  {
    title: 'Built around your business, not a template checklist',
    description: 'We don’t just swap placeholder text into a generic template. We design your page structure around how your actual customers evaluate trust and decide to contact you.'
  },
  {
    title: 'Design, development, SEO, and automation in one team',
    description: 'You don’t have to hire three separate freelancers who blame each other when something breaks. We connect design elegance with practical back-office workflows.'
  },
  {
    title: 'React-based development for fast, modern experiences',
    description: 'We build custom, snappy web frontends that load quickly on mobile devices and provide smooth, app-like interactions without cumbersome plugin bloat.'
  },
  {
    title: 'Clear communication without technical jargon',
    description: 'We don’t present basic commodity items like SSL or domain records as revolutionary breakthroughs. We focus on business outcomes and clear digital clarity.'
  },
  {
    title: 'A free consultation before committing to a build',
    description: 'You get a relaxed, no-pressure conversation where we evaluate your needs first. If you don’t need a new website yet, we’ll tell you honestly.'
  }
];

export const PROCESS_STEPS = [
  {
    step: '01',
    name: 'Understand',
    title: 'Learn about the business',
    desc: 'We begin with a focused conversation to understand who your customers are, how they find you, and what current friction is slowing you down.'
  },
  {
    step: '02',
    name: 'Recommend',
    title: 'Identify what will genuinely help',
    desc: 'We map out the exact digital solution: a focused website, an automated lead flow, or both—keeping the scope practical and honest.'
  },
  {
    step: '03',
    name: 'Build',
    title: 'Design & develop with precision',
    desc: 'We craft clean layouts, responsive React code, and reliable workflow connections with rigorous attention to speed and mobile usability.'
  },
  {
    step: '04',
    name: 'Improve',
    title: 'Launch & guide your team',
    desc: 'We launch with strong SEO foundations, provide clear walkthroughs, and ensure your team is confident using the new digital system.'
  }
];

export const FAQS = [
  {
    question: 'How do I know if my business needs a website, an automation, or both?',
    answer: 'If potential customers struggle to find credible information about your services, pricing, or location on mobile, you need a high-trust website. If your team is spending hours manually copying inquiries into spreadsheets, sending repetitive email follow-ups, or booking appointments by hand, you need workflow automation. If both apply, we build a cohesive system. During our free consultation, we help you pinpoint the highest-impact starting point.'
  },
  {
    question: 'What is included in the ₹11,500, ₹17,500, and ₹22,999 pricing tiers?',
    answer: 'These pricing tiers represent transparent starting points for our custom website builds. Starter (₹11,500) covers focused single/multi-section presence with direct contact flows; Growth (₹17,500) delivers a multi-page setup with structured conversion architecture; and Premium (₹22,999) delivers bespoke React interactions and advanced lead routing. Final scope is explicitly confirmed during your free consultation so there are never hidden surprises.'
  },
  {
    question: 'Are domain names, hosting, or third-party subscriptions included?',
    answer: 'To ensure you retain 100% ownership and control over your digital assets, domain registration and hosting accounts are held directly in your name. We guide you through the simple setup step-by-step and connect everything seamlessly without any markup or hostage lock-ins.'
  },
  {
    question: 'Do you work with international clients outside of India?',
    answer: 'Yes! While WebMint is proudly based in India and quotes standard packages in INR, we work with startups, businesses, and agencies worldwide. We handle scheduling across timezones and provide custom quotes in USD / EUR / GBP upon request.'
  },
  {
    question: 'How long does a typical WebMint project take?',
    answer: 'Because we operate with a focused, hands-on team without bureaucratic agency layers, most Starter and Growth websites are completed within 7 to 14 business days once content and goals are aligned. Custom automations and complex web apps depend on scope, which we map out clearly upfront.'
  },
  {
    question: 'What happens during the Free Consultation?',
    answer: 'It is a 25-minute, zero-pressure conversation via Google Meet or phone. We ask questions about your business, assess what digital tools you currently use, and give you an objective recommendation. If you don’t need a new website or automation right now, we will say so candidly.'
  }
];
