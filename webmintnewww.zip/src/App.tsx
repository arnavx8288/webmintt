import React, { useState, useEffect } from 'react';
import { PageId } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';

// Pages
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { WebDevPage } from './pages/WebDevPage';
import { AutomationPage } from './pages/AutomationPage';
import { PricingPage } from './pages/PricingPage';
import { AboutPage } from './pages/AboutPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';

export function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [consultationPresetType, setConsultationPresetType] = useState<
    'Website' | 'Automation' | 'Both' | 'Not sure yet'
  >('Not sure yet');
  const [consultationPresetNotes, setConsultationPresetNotes] = useState<string>('');

  // Scroll to top whenever page changes
  const handleNavigate = (page: PageId) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenConsultationWithPreset = (
    type: 'Website' | 'Automation' | 'Both' | 'Not sure yet' = 'Not sure yet',
    notes: string = ''
  ) => {
    setConsultationPresetType(type);
    setConsultationPresetNotes(notes);
    setCurrentPage('contact');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenConsultationForPackage = (packageName?: string) => {
    setConsultationPresetType('Website');
    setConsultationPresetNotes(packageName ? `Selected package interest: ${packageName}` : '');
    setCurrentPage('contact');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F8FAFA] text-[#0F172A] font-sans antialiased selection:bg-[#00D29E] selection:text-[#0A192F] flex flex-col justify-between">
      {/* Navigation Bar */}
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenConsultation={() => handleOpenConsultationWithPreset('Not sure yet')}
      />

      {/* Main Content Router */}
      <main className="flex-grow">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onOpenConsultationWithPreset={handleOpenConsultationWithPreset}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage
            onNavigate={handleNavigate}
            onOpenConsultation={(type) => handleOpenConsultationWithPreset(type || 'Not sure yet')}
          />
        )}

        {currentPage === 'web-dev' && (
          <WebDevPage
            onNavigate={handleNavigate}
            onOpenConsultation={(type) => handleOpenConsultationWithPreset(type || 'Website')}
          />
        )}

        {currentPage === 'automation' && (
          <AutomationPage
            onNavigate={handleNavigate}
            onOpenConsultation={(type) => handleOpenConsultationWithPreset(type || 'Automation')}
          />
        )}

        {currentPage === 'pricing' && (
          <PricingPage
            onNavigate={handleNavigate}
            onOpenConsultation={handleOpenConsultationForPackage}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage
            onNavigate={handleNavigate}
            onOpenConsultation={() => handleOpenConsultationWithPreset('Not sure yet')}
          />
        )}

        {currentPage === 'portfolio' && (
          <PortfolioPage
            onNavigate={handleNavigate}
            onOpenConsultation={(type) => handleOpenConsultationWithPreset(type || 'Website')}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            initialHelpType={consultationPresetType}
            initialNotes={consultationPresetNotes}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'privacy' && <PrivacyPage onNavigate={handleNavigate} />}

        {currentPage === 'terms' && <TermsPage onNavigate={handleNavigate} />}
      </main>

      {/* Comprehensive Site Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenConsultation={() => handleOpenConsultationWithPreset('Not sure yet')}
      />
    </div>
  );
}

export default App;
