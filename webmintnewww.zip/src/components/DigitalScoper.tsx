import React, { useState } from 'react';
import { PageId } from '../types';
import { Globe, Cpu, Sparkles, Check, ArrowRight, RefreshCw, Layers } from 'lucide-react';

interface DigitalScoperProps {
  onSelectOption: (type: 'Website' | 'Automation' | 'Both', notes: string) => void;
  onNavigateToPricing: () => void;
}

export const DigitalScoper: React.FC<DigitalScoperProps> = ({
  onSelectOption,
  onNavigateToPricing,
}) => {
  const [challenge, setChallenge] = useState<string>('visibility');
  const [inquiryVolume, setInquiryVolume] = useState<string>('manual');
  const [stage, setStage] = useState<string>('growing');

  const calculateRecommendation = () => {
    if (challenge === 'visibility' && inquiryVolume === 'low') {
      return {
        type: 'Website' as const,
        title: 'High-Trust Website Foundation',
        tagline: 'Establish your brand credibility and local discovery first.',
        reason: 'Your main goal is helping customers find and trust you on mobile. A fast, modern website gives you a professional digital presence without unnecessary complexity.',
        bestPackage: 'Starter (₹11,500) or Growth (₹17,500)',
        nextStep: 'Create a clean, responsive site with direct contact / WhatsApp actions.'
      };
    } else if (challenge === 'operations' || inquiryVolume === 'overwhelmed') {
      return {
        type: 'Automation' as const,
        title: 'Workflow & Lead Automation',
        tagline: 'Reclaim manual hours spent copying leads, bookings, and messages.',
        reason: 'You already receive inquiries or traffic, but your team wastes valuable hours on manual follow-ups, calendar coordination, or data entry.',
        bestPackage: 'Custom Workflow Integration',
        nextStep: 'Connect your intake forms to instant CRM, Slack, or automated email follow-ups.'
      };
    } else {
      return {
        type: 'Both' as const,
        title: 'Connected Digital System (Web + Automation)',
        tagline: 'A seamless front-end experience backed by automated operations.',
        reason: 'You need both a credible, modern storefront to convert visitors and an automated back-office flow to route leads, appointments, and payments instantly.',
        bestPackage: 'Growth or Premium Website with Workflow Routing',
        nextStep: 'Build a bespoke web experience with automated lead triage.'
      };
    }
  };

  const rec = calculateRecommendation();

  const handleApplyToConsultation = () => {
    const summaryNotes = `Assessment Scoper: Challenge: ${challenge}, Volume: ${inquiryVolume}, Stage: ${stage}. Recommended: ${rec.title}`;
    onSelectOption(rec.type, summaryNotes);
  };

  return (
    <div
      id="interactive-digital-scoper"
      className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)]"
    >
      <div className="max-w-2xl mx-auto text-center mb-6">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-semibold uppercase tracking-wider mb-1.5">
          <Layers className="w-3 h-3 text-[#00D29E]" />
          <span>Interactive Assessment</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-display font-bold text-[#0A192F] mb-1">
          Not sure what your business needs?
        </h3>
        <p className="text-slate-600 text-xs sm:text-sm">
          Answer 3 quick questions to get an instant, honest recommendation before booking.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Question 1 */}
        <div className="bg-slate-50/90 p-4 rounded-xl shadow-2xs flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#047857] uppercase tracking-wider block mb-0.5">
              Step 1: Current Challenge
            </span>
            <label className="text-xs font-semibold text-slate-800 block mb-2">
              Where is the biggest friction today?
            </label>
          </div>
          <div className="space-y-1.5">
            {[
              { id: 'visibility', label: 'People don’t know or trust our services online' },
              { id: 'operations', label: 'We spend hours answering repetitive questions & copying data' },
              { id: 'both', label: 'We need both a modern brand and streamlined operations' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setChallenge(opt.id)}
                className={`w-full text-left p-2.5 rounded-lg text-xs transition-all cursor-pointer ${
                  challenge === opt.id
                    ? 'bg-white ring-2 ring-[#00D29E] text-[#0A192F] font-semibold shadow-2xs'
                    : 'bg-white text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Question 2 */}
        <div className="bg-slate-50/90 p-4 rounded-xl shadow-2xs flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#047857] uppercase tracking-wider block mb-0.5">
              Step 2: Inquiry Handling
            </span>
            <label className="text-xs font-semibold text-slate-800 block mb-2">
              How do you handle prospective leads?
            </label>
          </div>
          <div className="space-y-1.5">
            {[
              { id: 'low', label: 'Just starting out / Low volume of inbound messages' },
              { id: 'manual', label: 'Moderate volume / Handled manually via DMs & phone' },
              { id: 'overwhelmed', label: 'High volume / Leads slip through or reply late' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setInquiryVolume(opt.id)}
                className={`w-full text-left p-2.5 rounded-lg text-xs transition-all cursor-pointer ${
                  inquiryVolume === opt.id
                    ? 'bg-white ring-2 ring-[#00D29E] text-[#0A192F] font-semibold shadow-2xs'
                    : 'bg-white text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Question 3 */}
        <div className="bg-slate-50/90 p-4 rounded-xl shadow-2xs flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#047857] uppercase tracking-wider block mb-0.5">
              Step 3: Business Stage
            </span>
            <label className="text-xs font-semibold text-slate-800 block mb-2">
              What best describes your team?
            </label>
          </div>
          <div className="space-y-1.5">
            {[
              { id: 'new', label: 'New business or local practice launching soon' },
              { id: 'growing', label: 'Established business ready for a modern upgrade' },
              { id: 'agency', label: 'Agency / Startup needing dedicated dev & ops execution' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setStage(opt.id)}
                className={`w-full text-left p-2.5 rounded-lg text-xs transition-all cursor-pointer ${
                  stage === opt.id
                    ? 'bg-white ring-2 ring-[#00D29E] text-[#0A192F] font-semibold shadow-2xs'
                    : 'bg-white text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Result Box */}
      <div className="bg-[#0A192F] text-white rounded-xl p-5 sm:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-lg">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#00D29E] bg-[#00D29E]/10 px-2 py-0.5 rounded-full">
              Recommended Focus: {rec.type}
            </span>
            <span className="text-[11px] text-slate-400">({rec.bestPackage})</span>
          </div>

          <h4 className="text-base sm:text-lg font-display font-bold text-white">
            {rec.title}
          </h4>

          <p className="text-slate-300 text-xs leading-relaxed">
            {rec.reason}
          </p>

          <p className="text-[11px] text-slate-400">
            <strong className="text-slate-200">Recommended Next Step:</strong> {rec.nextStep}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row md:flex-col gap-2 w-full md:w-auto shrink-0">
          <button
            type="button"
            id="scoper-apply-consultation-btn"
            onClick={handleApplyToConsultation}
            className="px-4 py-2.5 rounded-lg bg-[#00D29E] text-[#0A192F] font-display font-bold text-xs hover:bg-[#00e8af] transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs text-center"
          >
            <span>Book with this Plan</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onNavigateToPricing}
            className="px-3.5 py-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-xs font-medium transition-colors text-center cursor-pointer"
          >
            View Pricing Options
          </button>
        </div>
      </div>
    </div>
  );
};
