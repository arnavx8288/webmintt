import React from 'react';
import { PageId } from '../types';
import { Logo } from './Logo';
import { BRAND_CONFIG } from '../data/config';
import { ArrowUpRight, Mail, Instagram, ShieldCheck, Phone, MessageCircle, Calendar } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  const handleNav = (pageId: PageId) => {
    onNavigate(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      id="main-footer"
      className="bg-[#0A192F] text-slate-300 pt-10 pb-8 border-t border-slate-800"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Upper Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-6 pb-8 border-b border-slate-800/80">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-3">
            <Logo
              size="md"
              lightMode={true}
              showTagline={true}
              onClick={() => handleNav('home')}
            />
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              We understand your business first, then recommend and build the right digital system—whether that is a high-quality website, workflow automation, or both.
            </p>
            
            <div className="pt-1 flex flex-wrap items-center gap-2">
              <a
                id="footer-email-link"
                href={`mailto:${BRAND_CONFIG.contactEmail}`}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 text-[11px] font-medium text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
              >
                <Mail className="w-3 h-3 text-[#00D29E]" />
                <span>{BRAND_CONFIG.contactEmail}</span>
              </a>

              <a
                id="footer-whatsapp-link"
                href={BRAND_CONFIG.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-950/60 border border-emerald-800/50 text-[11px] font-medium text-emerald-300 hover:text-white hover:bg-emerald-900/80 transition-colors"
              >
                <MessageCircle className="w-3 h-3 text-[#00D29E]" />
                <span>WhatsApp: {BRAND_CONFIG.phoneNumber}</span>
              </a>

              <a
                id="footer-instagram-link"
                href={BRAND_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 text-[11px] font-medium text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
              >
                <Instagram className="w-3 h-3 text-[#00D29E]" />
                <span>{BRAND_CONFIG.instagramHandle}</span>
                <ArrowUpRight className="w-2.5 h-2.5 text-slate-500" />
              </a>

              <a
                id="footer-calendly-link"
                href={BRAND_CONFIG.calendlyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-950/60 border border-blue-800/50 text-[11px] font-medium text-blue-300 hover:text-white hover:bg-blue-900/80 transition-colors"
              >
                <Calendar className="w-3 h-3 text-blue-400" />
                <span>Schedule Call</span>
                <ArrowUpRight className="w-2.5 h-2.5 text-slate-500" />
              </a>
            </div>

            <div className="pt-1 flex items-center gap-1.5 text-[11px] text-slate-500">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D29E]" />
              <span>{BRAND_CONFIG.primaryLocation}</span>
            </div>
          </div>

          {/* Solutions / Services */}
          <div>
            <h4 className="text-white text-xs font-semibold tracking-wide uppercase font-display mb-2.5">
              Solutions
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  id="footer-link-services"
                  onClick={() => handleNav('services')}
                  className="hover:text-white transition-colors text-left"
                >
                  Services Overview
                </button>
              </li>
              <li>
                <button
                  id="footer-link-webdev"
                  onClick={() => handleNav('web-dev')}
                  className="hover:text-white transition-colors text-left flex items-center gap-1.5"
                >
                  <span>Website Development</span>
                  <span className="text-[9px] text-[#00D29E] bg-[#00D29E]/10 px-1 rounded">₹11.5k+</span>
                </button>
              </li>
              <li>
                <button
                  id="footer-link-automation"
                  onClick={() => handleNav('automation')}
                  className="hover:text-white transition-colors text-left"
                >
                  Workflow Automation
                </button>
              </li>
              <li>
                <button
                  id="footer-link-pricing"
                  onClick={() => handleNav('pricing')}
                  className="hover:text-white transition-colors text-left"
                >
                  Transparent Pricing
                </button>
              </li>
            </ul>
          </div>

          {/* Agency */}
          <div>
            <h4 className="text-white text-xs font-semibold tracking-wide uppercase font-display mb-2.5">
              Agency
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  id="footer-link-about"
                  onClick={() => handleNav('about')}
                  className="hover:text-white transition-colors text-left"
                >
                  About WebMint & Team
                </button>
              </li>
              <li>
                <button
                  id="footer-link-portfolio"
                  onClick={() => handleNav('portfolio')}
                  className="hover:text-white transition-colors text-left"
                >
                  Selected Work & Gallery
                </button>
              </li>
              <li>
                <a
                  id="footer-link-ig-portfolio"
                  href={BRAND_CONFIG.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors text-left inline-flex items-center gap-1"
                >
                  <span>Instagram Portfolio</span>
                  <ArrowUpRight className="w-2.5 h-2.5 text-slate-500" />
                </a>
              </li>
              <li>
                <button
                  id="footer-link-contact"
                  onClick={() => handleNav('contact')}
                  className="hover:text-white transition-colors text-left"
                >
                  Book Free Consultation
                </button>
              </li>
            </ul>
          </div>

          {/* Free Digital Assessment Card */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/60 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-[10px] font-semibold text-[#00D29E] uppercase tracking-wider mb-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>No-Pressure Guidance</span>
              </div>
              <h5 className="text-white text-xs font-medium mb-1">
                Not sure what your business needs?
              </h5>
              <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                We'll honestly tell you whether a website, an automation, or a simple tool is your best next move.
              </p>
            </div>
            <button
              id="footer-consultation-btn"
              onClick={onOpenConsultation}
              className="w-full py-2 px-3 rounded-lg bg-[#00D29E] text-[#0A192F] text-xs font-bold hover:bg-[#00e8af] transition-colors cursor-pointer text-center"
            >
              Get a Clear Digital Plan
            </button>
          </div>
        </div>

        {/* Lower Footer */}
        <div className="pt-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-400">
          <div className="flex items-center gap-1">
            <span>© {new Date().getFullYear()} WebMint Digital.</span>
            <span>Crafted with clarity for Indian & global businesses.</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              id="footer-link-privacy"
              onClick={() => handleNav('privacy')}
              className="hover:text-slate-200 transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-slate-700">•</span>
            <button
              id="footer-link-terms"
              onClick={() => handleNav('terms')}
              className="hover:text-slate-200 transition-colors"
            >
              Terms of Service
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
