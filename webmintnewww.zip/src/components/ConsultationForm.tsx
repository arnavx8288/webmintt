import React, { useState } from 'react';
import { ConsultationFormData, DigitalPlanAnalysisResult } from '../types';
import { BRAND_CONFIG } from '../data/config';
import {
  Send,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Shield,
  Clock,
  Instagram,
  Mail,
  Loader2,
  HelpCircle,
  Check,
  AlertCircle,
  MessageCircle,
  Calendar,
  Phone,
  ArrowUpRight
} from 'lucide-react';

interface ConsultationFormProps {
  initialHelpType?: 'Website' | 'Automation' | 'Both' | 'Not sure yet';
  initialNotes?: string;
  onSuccess?: () => void;
  onViewPrivacy?: () => void;
}

export const ConsultationForm: React.FC<ConsultationFormProps> = ({
  initialHelpType = 'Not sure yet',
  initialNotes = '',
  onSuccess,
  onViewPrivacy,
}) => {
  const [formData, setFormData] = useState<ConsultationFormData>({
    name: '',
    businessName: '',
    email: '',
    phoneOrWhatsApp: '',
    country: 'India',
    businessType: 'Local Service Business',
    helpNeeded: initialHelpType,
    currentWebsiteOrSocial: '',
    businessGoal: initialNotes,
    preferredContact: 'Email',
    consent: true,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // AI Instant Plan Generator state
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<DigitalPlanAnalysisResult | null>(null);
  const [showAiHelper, setShowAiHelper] = useState(false);

  const businessTypes = [
    'Café, Restaurant or Bakery',
    'Gym, Yoga or Fitness Studio',
    'Real Estate & Property',
    'Local Service Business (Home/Trade)',
    'Professional Practice (Legal/Consulting/Clinic)',
    'Growing Startup / Tech Business',
    'Marketing, Design or Creator Agency',
    'E-commerce or Retail Brand',
    'Other / Solo Venture'
  ];

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({ ...prev, consent: e.target.checked }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.name.trim() || !formData.email.trim() || !formData.businessGoal.trim()) {
      setErrorMessage('Please fill in your name, email, and a brief note about your business goal.');
      return;
    }

    if (!formData.consent) {
      setErrorMessage('Please confirm agreement to our privacy terms before submitting.');
      return;
    }

    setIsSubmitting(true);

    try {
      // POST to backend consultation endpoint
      const response = await fetch('/api/consultation-inquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          aiPlanPreview: aiAnalysisResult,
          submittedAt: new Date().toISOString(),
        }),
      });

      if (!response.ok) {
        // Even if server is offline in fallback static mode, persist locally and confirm
        console.warn('Backend inquiry logged locally');
      }

      // Save inquiry to localStorage for reliable offline proofing
      const existing = JSON.parse(localStorage.getItem('webmint_inquiries') || '[]');
      existing.push({ ...formData, timestamp: new Date().toISOString() });
      localStorage.setItem('webmint_inquiries', JSON.stringify(existing));

      setIsSubmitted(true);
      if (onSuccess) onSuccess();
    } catch (err) {
      // Graceful fallback
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGenerateInstantAiPlan = async () => {
    if (!formData.businessGoal.trim() && !formData.businessName.trim()) {
      setErrorMessage('Please write a sentence or two in the "business goal" field above first so our AI planner has context.');
      return;
    }

    setAiAnalyzing(true);
    setErrorMessage('');

    try {
      const res = await fetch('/api/analyze-digital-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName: formData.businessName,
          businessType: formData.businessType,
          currentHelpNeeded: formData.helpNeeded,
          businessGoal: formData.businessGoal,
          currentWebsite: formData.currentWebsiteOrSocial,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setAiAnalysisResult(data);
        if (data.recommendation) {
          if (data.recommendation === 'Website') setFormData((p) => ({ ...p, helpNeeded: 'Website' }));
          else if (data.recommendation === 'Automation') setFormData((p) => ({ ...p, helpNeeded: 'Automation' }));
          else if (data.recommendation === 'Both') setFormData((p) => ({ ...p, helpNeeded: 'Both' }));
        }
      } else {
        // Fallback rule-based structured analysis if API key is not yet set
        setAiAnalysisResult({
          recommendation: formData.helpNeeded === 'Not sure yet' ? 'Start with Foundational Consultation' : formData.helpNeeded,
          summary: `Based on your ${formData.businessType} profile, WebMint recommends establishing clear, mobile-optimized customer conversion touchpoints first.`,
          keyInsights: [
            'Prioritize high-trust mobile responsiveness for local discovery',
            'Capture customer inquiries with zero friction (direct WhatsApp or smart form)',
            'Avoid heavy templates that slow down mobile customer evaluations'
          ],
          suggestedSteps: [
            '25-min scope & workflow discovery review',
            'Identify whether manual inquiry handling or visibility is the primary bottleneck',
            'Formulate a phased rollout with clear upfront pricing'
          ],
          whyThisFits: 'Ensures you spend only on what produces immediate clarity and operational relief.',
          avoidPitfalls: [
            'Do not pay for expensive unneeded software licenses',
            'Avoid generic templates that look identical to competitors'
          ]
        });
      }
    } catch (err) {
      setAiAnalysisResult({
        recommendation: 'Start with Foundational Consultation',
        summary: `Tailored plan ready for discussion during your call.`,
        keyInsights: ['Assess customer journey friction points', 'Eliminate manual copy-pasting of leads'],
        suggestedSteps: ['Review current inquiry flow on 25-min call'],
        whyThisFits: 'Direct human guidance tailored to your specific operations.',
        avoidPitfalls: ['Avoid commodity website packages that fail on mobile']
      });
    } finally {
      setAiAnalyzing(false);
    }
  };

  if (isSubmitted) {    return (
      <div
        id="consultation-form-success"
        className="bg-white rounded-2xl p-6 sm:p-8 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] text-center animate-in fade-in zoom-in-95 duration-300"
      >
        <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-7 h-7 text-[#00D29E]" />
        </div>

        <h3 className="text-lg sm:text-xl font-display font-bold text-[#0A192F] mb-2">
          Thanks—we’ve received your details!
        </h3>

        <p className="text-slate-600 text-xs sm:text-sm leading-relaxed max-w-md mx-auto mb-5">
          WebMint will review your business context and get back to you soon via{' '}
          <strong className="text-slate-900">{formData.preferredContact}</strong> ({formData.email}).
        </p>

        <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 max-w-md mx-auto text-left space-y-2 mb-5">
          <h4 className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 font-display">
            What happens next?
          </h4>
          <div className="flex items-start gap-2 text-xs text-slate-700">
            <div className="w-4 h-4 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
              1
            </div>
            <span>We review your website/social links and current workflow needs.</span>
          </div>
          <div className="flex items-start gap-2 text-xs text-slate-700">
            <div className="w-4 h-4 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
              2
            </div>
            <span>We send calendar slots for a relaxed 25-minute video or audio call.</span>
          </div>
          <div className="flex items-start gap-2 text-xs text-slate-700">
            <div className="w-4 h-4 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
              3
            </div>
            <span>We provide honest, objective advice—even if you don’t need our services yet.</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-600">
          <a
            href={BRAND_CONFIG.calendlyUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 font-semibold hover:bg-blue-100 transition-colors text-xs"
          >
            <Calendar className="w-3 h-3 text-blue-600" />
            <span>Book on Calendly</span>
            <ArrowUpRight className="w-2.5 h-2.5 text-blue-500" />
          </a>

          <a
            href={BRAND_CONFIG.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 font-semibold hover:bg-emerald-100 transition-colors text-xs"
          >
            <MessageCircle className="w-3 h-3 text-[#00D29E]" />
            <span>WhatsApp</span>
          </a>

          <a
            href={`mailto:${BRAND_CONFIG.contactEmail}`}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-medium hover:bg-slate-200 transition-colors text-xs"
          >
            <Mail className="w-3 h-3 text-slate-600" />
            <span>Email</span>
          </a>
        </div>

        <button
          onClick={() => {
            setIsSubmitted(false);
            setFormData({
              name: '',
              businessName: '',
              email: '',
              phoneOrWhatsApp: '',
              country: 'India',
              businessType: 'Local Service Business',
              helpNeeded: 'Not sure yet',
              currentWebsiteOrSocial: '',
              businessGoal: '',
              preferredContact: 'Email',
              consent: true,
            });
          }}
          className="mt-5 text-xs text-slate-400 hover:text-slate-700 underline cursor-pointer"
        >
          Submit another inquiry
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)]" id="consultation-form-card">
      <div className="mb-4">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold tracking-wide uppercase">
            <Clock className="w-3 h-3 text-[#00D29E]" />
            <span>{BRAND_CONFIG.consultationDuration}</span>
          </div>

          <a
            id="form-top-calendly-btn"
            href={BRAND_CONFIG.calendlyUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold hover:bg-blue-100 transition-colors"
          >
            <Calendar className="w-3 h-3 text-blue-600" />
            <span>Prefer Calendly? Pick a slot</span>
            <ArrowUpRight className="w-2.5 h-2.5 text-blue-500" />
          </a>
        </div>
        <h3 className="text-lg sm:text-xl font-display font-bold text-[#0A192F] mb-1">
          Book a Free Consultation
        </h3>
        <p className="text-slate-600 text-xs leading-relaxed">
          Not sure whether you need a website, automation, or neither? Tell us about your business and we'll give you clear, honest guidance.
        </p>
      </div>

      {errorMessage && (
        <div className="mb-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4" id="consultation-intake-form">
        {/* Row 1: Name & Business Name */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label htmlFor="form-name" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
              Your Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              id="form-name"
              name="name"
              required
              value={formData.name}
              onChange={handleInputChange}
              placeholder="e.g. Rahul Sharma"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
            />
          </div>

          <div>
            <label htmlFor="form-business-name" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
              Business / Project Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              id="form-business-name"
              name="businessName"
              required
              value={formData.businessName}
              onChange={handleInputChange}
              placeholder="e.g. Blue Bean Coffee"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
            />
          </div>
        </div>

        {/* Row 2: Email & Phone */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label htmlFor="form-email" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
              Email Address <span className="text-rose-500">*</span>
            </label>
            <input
              type="email"
              id="form-email"
              name="email"
              required
              value={formData.email}
              onChange={handleInputChange}
              placeholder="you@company.com"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
            />
          </div>

          <div>
            <label htmlFor="form-phone" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
              Phone / WhatsApp <span className="text-slate-400 text-[10px] lowercase">(optional)</span>
            </label>
            <input
              type="tel"
              id="form-phone"
              name="phoneOrWhatsApp"
              value={formData.phoneOrWhatsApp}
              onChange={handleInputChange}
              placeholder="+91 98765 43210"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
            />
          </div>
        </div>

        {/* Row 3: Country & Business Type */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label htmlFor="form-country" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
              Country / Location
            </label>
            <select
              id="form-country"
              name="country"
              value={formData.country}
              onChange={handleInputChange}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
            >
              <option value="India">India (INR Pricing)</option>
              <option value="United States">United States</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="Canada">Canada</option>
              <option value="Australia">Australia</option>
              <option value="United Arab Emirates">United Arab Emirates</option>
              <option value="Singapore">Singapore</option>
              <option value="Other International">Other International</option>
            </select>
          </div>

          <div>
            <label htmlFor="form-business-type" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
              Business Type
            </label>
            <select
              id="form-business-type"
              name="businessType"
              value={formData.businessType}
              onChange={handleInputChange}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
            >
              {businessTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* What do you need help with? */}
        <div>
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
            What do you need help with? <span className="text-rose-500">*</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {(['Website', 'Automation', 'Both', 'Not sure yet'] as const).map((option) => (
              <button
                type="button"
                key={option}
                id={`help-option-${option.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setFormData((prev) => ({ ...prev, helpNeeded: option }))}
                className={`py-2 px-2.5 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                  formData.helpNeeded === option
                    ? 'border-[#00D29E] bg-emerald-50/70 text-[#0A192F] font-bold ring-1 ring-[#00D29E]/30 shadow-2xs'
                    : 'border-slate-200 bg-slate-50/40 text-slate-700 hover:bg-slate-100/60'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Current website or Instagram link */}
        <div>
          <label htmlFor="form-current-link" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1">
            Current Website or Instagram Link <span className="text-slate-400 text-[10px] lowercase">(optional)</span>
          </label>
          <input
            type="text"
            id="form-current-link"
            name="currentWebsiteOrSocial"
            value={formData.currentWebsiteOrSocial}
            onChange={handleInputChange}
            placeholder="e.g. instagram.com/mybusiness or https://mybusiness.com"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all"
          />
        </div>

        {/* Business and goal context */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label htmlFor="form-goal" className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700">
              Tell us briefly about your business & goal <span className="text-rose-500">*</span>
            </label>

            {/* Instant AI Plan Helper Button */}
            <button
              type="button"
              id="btn-ai-plan-helper"
              onClick={handleGenerateInstantAiPlan}
              disabled={aiAnalyzing}
              className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#047857] hover:text-[#064e3b] bg-emerald-50 hover:bg-emerald-100/80 px-2 py-0.5 rounded-lg transition-colors cursor-pointer"
            >
              {aiAnalyzing ? (
                <>
                  <Loader2 className="w-2.5 h-2.5 animate-spin text-[#00D29E]" />
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-2.5 h-2.5 text-[#00D29E]" />
                  <span>Get Instant AI Plan Preview</span>
                </>
              )}
            </button>
          </div>

          <textarea
            id="form-goal"
            name="businessGoal"
            required
            rows={3}
            value={formData.businessGoal}
            onChange={handleInputChange}
            placeholder="e.g. We are a boutique gym in Pune. Right now, members ask for schedules via Instagram DMs and we manually record inquiries in Excel. We want a clear schedule site and automated trial pass bookings."
            className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#00D29E]/30 focus:border-[#00D29E] transition-all leading-relaxed"
          />
        </div>

        {/* AI Analysis Result Card (if generated) */}
        {aiAnalysisResult && (
          <div className="p-3.5 rounded-xl bg-slate-900 text-slate-100 border border-slate-800 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-1 text-[11px] font-bold text-[#00D29E] uppercase tracking-wider">
                <Sparkles className="w-3 h-3" />
                <span>WebMint Initial Scope Recommendation</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                AI Preview
              </span>
            </div>

            <p className="text-xs font-medium text-white">
              Recommended Focus: <span className="text-[#00D29E]">{aiAnalysisResult.recommendation}</span>
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              {aiAnalysisResult.summary}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs">
              <div className="bg-slate-800/60 p-2.5 rounded-lg border border-slate-700/50">
                <span className="font-semibold text-slate-200 block mb-0.5 text-[11px]">Key Insights:</span>
                <ul className="space-y-0.5 text-slate-400 text-[11px]">
                  {aiAnalysisResult.keyInsights.slice(0, 3).map((item, idx) => (
                    <li key={idx} className="flex items-start gap-1">
                      <span className="text-[#00D29E] mt-0.5">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-800/60 p-2.5 rounded-lg border border-slate-700/50">
                <span className="font-semibold text-slate-200 block mb-0.5 text-[11px]">Recommended Agenda:</span>
                <ul className="space-y-0.5 text-slate-400 text-[11px]">
                  {aiAnalysisResult.suggestedSteps.slice(0, 3).map((step, idx) => (
                    <li key={idx} className="flex items-start gap-1">
                      <span className="text-[#00D29E] mt-0.5">→</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 italic pt-0.5">
              Note: This recommendation is an initial starting point and will be refined during your free consultation.
            </p>
          </div>
        )}

        {/* Preferred Contact Method */}
        <div>
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
            Preferred Contact Method
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['Email', 'WhatsApp', 'Google Meet'] as const).map((method) => (
              <button
                type="button"
                key={method}
                id={`contact-pref-${method.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setFormData((prev) => ({ ...prev, preferredContact: method }))}
                className={`py-2 px-2.5 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                  formData.preferredContact === method
                    ? 'border-[#00D29E] bg-emerald-50 text-[#0A192F] font-bold'
                    : 'border-slate-200 bg-slate-50/40 text-slate-700 hover:bg-slate-100/60'
                }`}
              >
                {method}
              </button>
            ))}
          </div>
        </div>

        {/* Consent Checkbox */}
        <div className="flex items-start gap-2 pt-1">
          <input
            type="checkbox"
            id="form-consent"
            checked={formData.consent}
            onChange={handleCheckboxChange}
            className="w-3.5 h-3.5 rounded border-slate-300 text-[#00D29E] focus:ring-[#00D29E] mt-0.5 cursor-pointer"
          />
          <label htmlFor="form-consent" className="text-[11px] text-slate-600 leading-relaxed cursor-pointer">
            I agree that WebMint may contact me regarding this inquiry. View our{' '}
            <button
              type="button"
              onClick={onViewPrivacy}
              className="text-[#0A192F] font-semibold underline hover:text-[#00D29E] cursor-pointer"
            >
              Privacy Policy
            </button>
            . We will never spam or sell your information.
          </label>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          id="consultation-submit-button"
          disabled={isSubmitting}
          className="w-full py-3 px-5 rounded-xl bg-[#0A192F] text-white font-display font-semibold text-xs sm:text-sm hover:bg-[#132845] active:scale-[0.99] transition-all shadow-xs flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-70"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-[#00D29E]" />
              <span>Sending inquiry...</span>
            </>
          ) : (
            <>
              <span>Book My Free Consultation</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#00D29E] transition-transform group-hover:translate-x-1" />
            </>
          )}
        </button>

        <p className="text-center text-[10px] text-slate-500">
          Zero commitment • No credit card required • Honest assessment
        </p>
      </form>
    </div>
  );
};
