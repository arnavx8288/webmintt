import React, { useState, useEffect } from 'react';
import { PageId, NavItem } from '../types';
import { Logo } from './Logo';
import { Menu, X, ArrowRight, ChevronDown, Sparkles, MessageSquare } from 'lucide-react';

interface HeaderProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onOpenConsultation: () => void;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Home', pageId: 'home' },
  { label: 'Services', pageId: 'services' },
  { label: 'Pricing', pageId: 'pricing' },
  { label: 'Portfolio', pageId: 'portfolio' },
  { label: 'About', pageId: 'about' },
  { label: 'Contact', pageId: 'contact' },
];

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  onOpenConsultation,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (pageId: PageId) => {
    onNavigate(pageId);
    setMobileMenuOpen(false);
    setServicesDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAFBFB]/95 backdrop-blur-md shadow-xs border-b border-slate-200/80 py-2.5'
          : 'bg-transparent py-3.5'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Logo
            size="sm"
            onClick={() => handleNavClick('home')}
            className="focus:outline-hidden"
          />

          {/* Desktop Navigation */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-1 bg-white/85 backdrop-blur-xs px-3 py-1 rounded-full border border-slate-200/90 shadow-xs"
          >
            {NAV_ITEMS.map((item) => {
              const isActive =
                currentPage === item.pageId ||
                (item.pageId === 'services' &&
                  (currentPage === 'web-dev' || currentPage === 'automation'));

              if (item.pageId === 'services') {
                return (
                  <div
                    key={item.pageId}
                    className="relative"
                    onMouseEnter={() => setServicesDropdownOpen(true)}
                    onMouseLeave={() => setServicesDropdownOpen(false)}
                  >
                    <button
                      id="nav-services-btn"
                      onClick={() => handleNavClick('services')}
                      className={`px-3.5 py-2 text-sm font-medium rounded-full transition-colors inline-flex items-center gap-1 ${
                        isActive
                          ? 'text-[#0A192F] font-semibold bg-slate-100'
                          : 'text-slate-600 hover:text-[#0A192F] hover:bg-slate-50'
                      }`}
                    >
                      {item.label}
                      <ChevronDown
                        className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${
                          servicesDropdownOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {/* Services Dropdown */}
                    {servicesDropdownOpen && (
                      <div
                        id="services-menu-dropdown"
                        className="absolute top-full left-0 mt-1.5 w-64 bg-white rounded-xl shadow-lg border border-slate-200/90 p-2.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                      >
                        <button
                          id="nav-sub-services-all"
                          onClick={() => handleNavClick('services')}
                          className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors flex flex-col"
                        >
                          <span className="text-xs font-semibold text-[#0A192F]">
                            All Services Overview
                          </span>
                          <span className="text-[11px] text-slate-500">
                            Website, automation & consultation
                          </span>
                        </button>
                        <div className="h-px bg-slate-100 my-1" />
                        <button
                          id="nav-sub-web-dev"
                          onClick={() => handleNavClick('web-dev')}
                          className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors flex flex-col"
                        >
                          <span className="text-xs font-semibold text-[#0A192F] flex items-center justify-between">
                            Website Development
                            <span className="text-[10px] text-[#059669] bg-emerald-50 px-1.5 py-0.5 rounded font-mono">
                              From ₹11.5k
                            </span>
                          </span>
                          <span className="text-[11px] text-slate-500">
                            Custom, fast, responsive websites
                          </span>
                        </button>
                        <button
                          id="nav-sub-automation"
                          onClick={() => handleNavClick('automation')}
                          className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors flex flex-col"
                        >
                          <span className="text-xs font-semibold text-[#0A192F]">
                            Workflow Automation
                          </span>
                          <span className="text-[11px] text-slate-500">
                            Lead routing, CRM & ops workflows
                          </span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              }

              return (
                <button
                  key={item.pageId}
                  id={`nav-link-${item.pageId}`}
                  onClick={() => handleNavClick(item.pageId)}
                  className={`px-3.5 py-2 text-sm font-medium rounded-full transition-colors ${
                    isActive
                      ? 'text-[#0A192F] font-semibold bg-slate-100'
                      : 'text-slate-600 hover:text-[#0A192F] hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Desktop Right CTA */}
          <div className="hidden sm:flex items-center gap-2.5">
            <button
              id="header-consultation-cta"
              onClick={onOpenConsultation}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#0A192F] text-white text-xs font-semibold hover:bg-[#132845] active:scale-[0.98] transition-all shadow-xs group cursor-pointer"
            >
              <span>Book a Free Consultation</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#00D29E] transition-transform duration-200 group-hover:translate-x-0.5" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              id="mobile-quick-consult-btn"
              onClick={onOpenConsultation}
              className="px-3 py-1.5 rounded-full bg-[#0A192F] text-white text-xs font-medium"
            >
              Consultation
            </button>

            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle navigation menu"
              className="p-2.5 rounded-lg text-slate-700 hover:bg-slate-100 focus:outline-hidden min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 text-slate-900" />
              ) : (
                <Menu className="w-6 h-6 text-slate-900" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-drawer-nav"
          className="sm:hidden fixed inset-x-0 top-[60px] bg-[#FAFBFB]/98 backdrop-blur-lg border-b border-slate-200 shadow-xl px-5 py-6 animate-in slide-in-from-top-3 duration-200 max-h-[85vh] overflow-y-auto space-y-4"
        >
          <div className="flex flex-col gap-1">
            {NAV_ITEMS.map((item) => {
              const isActive = currentPage === item.pageId;
              return (
                <button
                  key={item.pageId}
                  id={`mobile-nav-${item.pageId}`}
                  onClick={() => handleNavClick(item.pageId)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors flex items-center justify-between min-h-[44px] ${
                    isActive
                      ? 'bg-slate-200/80 text-[#0A192F] font-semibold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.pageId === 'services' && (
                    <span className="text-[11px] text-slate-400 font-normal">
                      Web & Automation
                    </span>
                  )}
                </button>
              );
            })}

            {/* Sub-links on mobile for quick access */}
            <div className="pl-3.5 pr-2 py-1.5 flex flex-col gap-1 border-l-2 border-slate-200 ml-2 my-1">
              <button
                id="mobile-subnav-webdev"
                onClick={() => handleNavClick('web-dev')}
                className="text-left py-1.5 text-xs text-slate-600 hover:text-[#0A192F] flex items-center justify-between"
              >
                <span>↳ Website Development</span>
                <span className="text-[10px] text-emerald-600 font-mono font-semibold bg-emerald-50 px-1.5 py-0.5 rounded">From ₹11.5k</span>
              </button>
              <button
                id="mobile-subnav-automation"
                onClick={() => handleNavClick('automation')}
                className="text-left py-1.5 text-xs text-slate-600 hover:text-[#0A192F]"
              >
                <span>↳ Workflow Automation</span>
              </button>
            </div>

            <div className="pt-3 mt-2 border-t border-slate-200 flex flex-col gap-2.5">
              <button
                id="mobile-drawer-consultation-cta"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenConsultation();
                }}
                className="w-full py-3 px-4 rounded-xl bg-[#0A192F] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs cursor-pointer min-h-[44px]"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#00D29E]" />
                <span>Book a Free Consultation</span>
              </button>
              <p className="text-center text-[10px] text-slate-500">
                25-min relaxed call • No pushy sales • Indian & Global clients
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
