import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
  lightMode?: boolean;
  className?: string;
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showTagline = false,
  lightMode = false,
  className = '',
  onClick,
}) => {
  const iconSizes = {
    sm: 'w-6 h-6',
    md: 'w-7 h-7',
    lg: 'w-9 h-9',
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg',
  };

  return (
    <div
      className={`inline-flex items-center gap-2.5 cursor-pointer select-none group ${className}`}
      onClick={onClick}
      id="webmint-brand-logo"
    >
      {/* Authentic WebMint Brush W. Emblem */}
      <div className={`relative ${iconSizes[size]} flex items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-105 ${lightMode ? 'bg-[#0F172A] border border-slate-700' : 'bg-[#EBF2F7] border border-slate-200/80 shadow-xs'}`}>
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-[78%] h-[78%]"
        >
          {/* Stylized Brush Stroke W */}
          <path
            d="M26 32 C27 28, 33 26, 36 34 C39 42, 33 64, 30 73 C29 76, 25 76, 25 72 C25 64, 35 40, 42 30 C45 26, 48 30, 48 36 C48 45, 45 66, 44 74 C47 74, 52 68, 55 58 C59 44, 60 26, 64 24 C68 22, 70 26, 68 34 C65 48, 62 66, 56 75 C52 81, 46 82, 43 77 C40 72, 41 62, 43 50 C41 55, 34 76, 28 80 C23 83, 19 78, 20 70 C22 58, 24 40, 26 32 Z"
            fill={lightMode ? '#00D29E' : '#1E4E8C'}
          />
          {/* Distinctive Period Dot */}
          <circle
            cx="72"
            cy="74"
            r="6.5"
            fill={lightMode ? '#00D29E' : '#1E4E8C'}
          />
        </svg>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center tracking-tight">
          <span
            className={`font-display font-bold ${textSizes[size]} ${
              lightMode ? 'text-white' : 'text-[#0A192F]'
            }`}
          >
            Web
          </span>
          <span
            className={`font-display font-bold ${textSizes[size]} text-[#00D29E]`}
          >
            Mint
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#00D29E] ml-0.5 mb-1.5 opacity-80" />
        </div>
        {showTagline && (
          <span
            className={`text-[9px] tracking-widest font-semibold uppercase -mt-0.5 ${
              lightMode ? 'text-slate-400' : 'text-slate-500'
            }`}
          >
            Websites & Automation
          </span>
        )}
      </div>
    </div>
  );
};
