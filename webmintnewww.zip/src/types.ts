export type PageId =
  | 'home'
  | 'services'
  | 'web-dev'
  | 'automation'
  | 'pricing'
  | 'about'
  | 'portfolio'
  | 'contact'
  | 'privacy'
  | 'terms';

export interface NavItem {
  label: string;
  pageId: PageId;
  badge?: string;
}

export interface PricingTier {
  id: string;
  name: string;
  priceINR: string;
  priceNote?: string;
  tagline: string;
  bestFor: string;
  included: string[];
  scopeNote: string;
  isPopular?: boolean;
  ctaText: string;
}

export interface ServiceDetail {
  id: string;
  title: string;
  subtitle: string;
  shortDesc: string;
  iconName: string;
  badge: string;
  pageId: PageId;
  capabilities: {
    title: string;
    description: string;
  }[];
  whatToExpect: string[];
  whatWeAvoid: string[];
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: 'Website' | 'Automation' | 'Full Digital System';
  clientType: string;
  summary: string;
  deliverables: string[];
  tags: string[];
  isPlaceholder?: boolean;
  instagramUrl?: string;
  gradientTheme?: string;
}

export interface TeamMember {
  name: string;
  role: string;
  highlight: string;
  bio: string;
  expertise: string[];
}

export interface ConsultationFormData {
  name: string;
  businessName: string;
  email: string;
  phoneOrWhatsApp?: string;
  country: string;
  businessType: string;
  helpNeeded: 'Website' | 'Automation' | 'Both' | 'Not sure yet';
  currentWebsiteOrSocial?: string;
  businessGoal: string;
  preferredContact: 'Email' | 'WhatsApp' | 'Google Meet';
  consent: boolean;
}

export interface DigitalPlanAnalysisResult {
  recommendation: 'Website' | 'Automation' | 'Both' | 'Start with Foundational Consultation';
  summary: string;
  keyInsights: string[];
  suggestedSteps: string[];
  whyThisFits: string;
  avoidPitfalls: string[];
}
