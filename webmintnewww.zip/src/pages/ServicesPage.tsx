import React from 'react';
import { PageId } from '../types';
import { SERVICES_LIST } from '../data/config';
import { Globe, Cpu, MessageSquare, ArrowRight, CheckCircle2, ShieldCheck, Zap } from 'lucide-react';

interface ServicesPageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: (type?: 'Website' | 'Automation' | 'Both' | 'Not sure yet') => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 pb-14" id="services-page-container">
      {/* Header */}
      <div className="max-w-2xl space-y-2.5">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold uppercase tracking-wide">
          <ShieldCheck className="w-3 h-3 text-[#00D29E]" />
          <span>Need-Based Solutions</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
          We recommend what you actually need—not a one-size-fits-all package.
        </h1>

        <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
          Whether you need a high-trust modern website, an automated lead workflow, or a clear roadmap to stop wasting time on repetitive tasks, WebMint builds solutions tailored to your operational realities.
        </p>
      </div>

      {/* Services Breakdown Cards */}
      <div className="space-y-6">
        {/* Service 1: Website Development */}
        <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 space-y-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#047857] flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Service 01
            </span>
            <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
              Website Development
            </h2>
            <p className="text-slate-600 text-xs leading-relaxed">
              Modern, fast, responsive websites built around how customers discover, trust, and contact a business. We focus on clean React codebases, fast mobile loading, and clear messaging.
            </p>
            
            <div className="pt-1 flex flex-col sm:flex-row gap-2">
              <button
                onClick={() => onNavigate('web-dev')}
                className="px-4 py-2 rounded-full bg-[#0A192F] text-white text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
              >
                <span>Web Dev Details</span>
                <ArrowRight className="w-3 h-3 text-[#00D29E]" />
              </button>

              <button
                onClick={() => onOpenConsultation('Website')}
                className="px-4 py-2 rounded-full bg-slate-100 text-slate-800 text-xs font-semibold hover:bg-slate-200 transition-colors text-center cursor-pointer shadow-2xs"
              >
                Book Web Consultation
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 bg-slate-50/90 rounded-xl p-4 shadow-2xs">
            <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2.5 font-display">
              Core Deliverables
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="space-y-1.5">
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Strategy & Page Hierarchy</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">UI/UX Design & Typography</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">React & Responsive Development</span>
                </div>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">SEO-Ready Foundations</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">High-Performance (&lt;1.5s)</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Direct WhatsApp Actions</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Service 2: Workflow Automation */}
        <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 space-y-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-[#0f766e] flex items-center justify-center">
              <Cpu className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Service 02
            </span>
            <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
              Workflow Automation
            </h2>
            <p className="text-slate-600 text-xs leading-relaxed">
              Reduce repetitive work and create smoother internal processes. We eliminate manual data copying, missed lead follow-ups, and calendar chaos.
            </p>
            
            <div className="pt-1 flex flex-col sm:flex-row gap-2">
              <button
                onClick={() => onNavigate('automation')}
                className="px-4 py-2 rounded-full bg-[#0A192F] text-white text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
              >
                <span>Automation Details</span>
                <ArrowRight className="w-3 h-3 text-[#00D29E]" />
              </button>

              <button
                onClick={() => onOpenConsultation('Automation')}
                className="px-4 py-2 rounded-full bg-slate-100 text-slate-800 text-xs font-semibold hover:bg-slate-200 transition-colors text-center cursor-pointer shadow-2xs"
              >
                Book Ops Consultation
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 bg-slate-50/90 rounded-xl p-4 shadow-2xs">
            <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2.5 font-display">
              Automation Examples
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="space-y-1.5">
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Lead capture & instant follow-up</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Form-to-CRM / Slack routing</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Automated scheduling</span>
                </div>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Google Sheets / AirTable sync</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">Internal operational alerts</span>
                </div>
                <div className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                  <span className="text-slate-700">AI-assisted triage</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Service 3: Digital Consultation */}
        <div className="bg-[#0A192F] text-white rounded-2xl p-5 sm:p-7 shadow-[0_10px_35px_-5px_rgba(10,25,47,0.25)] grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 space-y-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-[#00D29E] flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#00D29E]">
              Zero-Commitment Assessment
            </span>
            <h2 className="text-lg sm:text-xl font-display font-bold text-white">
              Not every business needs the same solution.
            </h2>
            <p className="text-slate-300 text-xs leading-relaxed">
              Before you spend money on custom design or software, we listen to your business goals, identify current bottlenecks, and give you an honest recommendation on what will genuinely help.
            </p>
            
            <div className="pt-1">
              <button
                onClick={() => onOpenConsultation('Not sure yet')}
                className="px-4 py-2 rounded-full bg-[#00D29E] text-[#0A192F] font-display font-bold text-xs hover:bg-[#00e8af] transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Book a Free Consultation</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 bg-slate-800/80 rounded-xl p-4 shadow-inner">
            <h3 className="text-[10px] font-bold uppercase tracking-wider text-[#00D29E] mb-2.5 font-display">
              What We Promise
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                <span>Honest feedback—if you don't need a website or automation yet, we will tell you directly.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                <span>Plain English explanations with zero developer acronyms or technical gatekeeping.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
                <span>Actionable takeaways you can implement regardless of whether you choose to hire us.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
