import React from 'react';
import { PageId } from '../types';
import { SERVICES_LIST } from '../data/config';
import { Globe, ArrowRight, CheckCircle2, XCircle, ShieldCheck, Smartphone, Zap, Search, Layout } from 'lucide-react';

interface WebDevPageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: (type?: 'Website') => void;
}

export const WebDevPage: React.FC<WebDevPageProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  const service = SERVICES_LIST.find((s) => s.id === 'web-dev')!;

  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 pb-14" id="webdev-page-container">
      {/* Hero */}
      <div className="max-w-2xl space-y-2.5">
        <button
          onClick={() => onNavigate('services')}
          className="text-xs font-semibold text-slate-500 hover:text-slate-900 inline-flex items-center gap-1 mb-0.5 cursor-pointer"
        >
          <span>← Back to Services</span>
        </button>

        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold uppercase tracking-wide">
          <Globe className="w-3 h-3 text-[#00D29E]" />
          <span>Website Development</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
          Modern websites crafted around customer trust and action.
        </h1>

        <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
          We build modern, fast, and responsive websites for local businesses, growing startups, and boutique agencies. No generic template clones or heavy plugin bloat—just clean React engineering that looks sharp and loads instantly.
        </p>

        <div className="pt-1 flex flex-wrap items-center gap-3">
          <button
            onClick={() => onOpenConsultation('Website')}
            className="px-4 py-2 rounded-full bg-[#0A192F] text-white font-display font-semibold text-xs hover:bg-[#132845] transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
          >
            <span>Book Website Consultation</span>
            <ArrowRight className="w-3 h-3 text-[#00D29E]" />
          </button>

          <button
            onClick={() => onNavigate('pricing')}
            className="px-4 py-2 rounded-full bg-white border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors cursor-pointer shadow-2xs"
          >
            View Pricing (₹11.5k+)
          </button>
        </div>
      </div>

      {/* Capabilities Deep-Dive Grid */}
      <div className="space-y-4">
        <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
          What Goes Into Every WebMint Build
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {service.capabilities.map((cap, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_8px_25px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_12px_32px_-4px_rgba(15,23,42,0.09)] transition-all flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-bold text-[#00D29E] font-mono block mb-1">
                  0{idx + 1}
                </span>
                <h3 className="text-sm sm:text-base font-display font-bold text-[#0A192F] mb-1">
                  {cap.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {cap.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Honest Standards Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-emerald-50/70 rounded-2xl p-5 shadow-2xs">
          <h3 className="text-base font-display font-bold text-[#064E3B] mb-2.5 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#00D29E]" />
            <span>What You Can Expect</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-700">
            {service.whatToExpect.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-[#00D29E] font-bold mt-0.5">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-rose-50/60 rounded-2xl p-5 shadow-2xs">
          <h3 className="text-base font-display font-bold text-[#881337] mb-2.5 flex items-center gap-1.5">
            <XCircle className="w-4 h-4 text-rose-500" />
            <span>What We Strictly Avoid</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-700">
            {service.whatWeAvoid.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-rose-400 font-bold mt-0.5">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Target Audiences for Web Dev */}
      <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] space-y-4">
        <h3 className="text-base sm:text-lg font-display font-bold text-[#0A192F]">
          Built For Businesses That Rely On Customer Trust
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-50/90 p-3 rounded-xl shadow-2xs">
            <strong className="text-slate-900 block font-semibold mb-0.5">Cafés & Restaurants</strong>
            <p className="text-slate-600">Mobile menu, directions, timings, and direct WhatsApp reservation flows.</p>
          </div>
          <div className="bg-slate-50/90 p-3 rounded-xl shadow-2xs">
            <strong className="text-slate-900 block font-semibold mb-0.5">Gyms & Studios</strong>
            <p className="text-slate-600">Class schedules, trainer bios, trial pass registrations, and location maps.</p>
          </div>
          <div className="bg-slate-50/90 p-3 rounded-xl shadow-2xs">
            <strong className="text-slate-900 block font-semibold mb-0.5">Professional Practices</strong>
            <p className="text-slate-600">High-trust legal, clinic, or advisory profiles with confidential intake.</p>
          </div>
          <div className="bg-slate-50/90 p-3 rounded-xl shadow-2xs">
            <strong className="text-slate-900 block font-semibold mb-0.5">Startups & Agencies</strong>
            <p className="text-slate-600">Product storytelling, clear feature matrices, and investor/client credibility.</p>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="bg-[#0A192F] rounded-2xl p-6 sm:p-8 text-white text-center space-y-3">
        <h3 className="text-lg sm:text-xl font-display font-bold">
          Ready to build a website that truly works on mobile?
        </h3>
        <p className="text-slate-300 text-xs max-w-lg mx-auto">
          Start with a relaxed 25-minute consultation to review your goals, current presence, and realistic scope.
        </p>
        <button
          onClick={() => onOpenConsultation('Website')}
          className="px-5 py-2.5 rounded-full bg-[#00D29E] text-[#0A192F] font-display font-bold text-xs hover:bg-[#00e8af] transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
        >
          <span>Book a Free Consultation</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
