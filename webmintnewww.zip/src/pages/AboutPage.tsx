import React from 'react';
import { PageId } from '../types';
import { TEAM_MEMBERS, CORE_VALUES, BRAND_CONFIG } from '../data/config';
import { ArrowRight, ShieldCheck, Heart, Sparkles, CheckCircle2 } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 sm:space-y-10 pb-14" id="about-page-container">
      {/* Header / Intro */}
      <div className="max-w-2xl space-y-2.5">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold uppercase tracking-wide">
          <ShieldCheck className="w-3 h-3 text-[#00D29E]" />
          <span>Our Story & Philosophy</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
          WebMint was built for businesses that want clarity, not technical confusion.
        </h1>

        <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
          We are a focused, modern digital team based in India, bringing together experience across audience psychology, growth analytics, design, React web engineering, and practical workflow automation.
        </p>
      </div>

      {/* Grounded Narrative */}
      <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] space-y-3">
        <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
          Why We Started WebMint
        </h2>
        <div className="space-y-2.5 text-slate-700 text-xs sm:text-sm leading-relaxed max-w-3xl">
          <p>
            When we looked at the web agency landscape, we noticed two extremes: expensive enterprise consultancies charging astronomical fees for simple projects, or low-cost agencies handing out rigid, generic templates that break on mobile and offer zero help with day-to-day operations.
          </p>
          <p>
            Most business owners don’t need an agency to lecture them with confusing technical jargon about servers or SSL certificates. What they really need is a clear answer to a fundamental question:
          </p>
          <blockquote className="p-3 bg-slate-50 border-l-3 border-[#00D29E] rounded-r-lg text-[#0A192F] font-medium italic text-xs sm:text-sm">
            “What digital setup will genuinely help my business attract customers and run without manual chaos?”
          </blockquote>
          <p>
            That’s why WebMint was built. We start with a no-pressure consultation to understand your real business bottlenecks, recommend only what is necessary, and build fast, clean digital systems that last.
          </p>
        </div>
      </div>

      {/* Team Context (Factual, grounded, non-overstated) */}
      <div className="space-y-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-display">
            The Core Team
          </span>
          <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
            Directly involved in every project
          </h2>
          <p className="text-slate-600 text-xs mt-0.5">
            You work directly with the people designing, building, and automating your system.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {TEAM_MEMBERS.map((member) => (
            <div
              key={member.name}
              className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_8px_25px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_12px_32px_-4px_rgba(15,23,42,0.09)] transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-9 h-9 rounded-lg bg-[#0A192F] text-[#00D29E] flex items-center justify-center font-display font-bold text-sm mb-3">
                  {member.name.charAt(0)}
                </div>

                <h3 className="text-base font-display font-bold text-[#0A192F]">
                  {member.name}
                </h3>
                <span className="text-xs font-medium text-slate-500 block mb-2">
                  {member.role}
                </span>

                <div className="bg-slate-50 p-2 rounded-md border border-slate-100 mb-2.5">
                  <span className="text-xs font-semibold text-emerald-800 block">
                    {member.highlight}
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  {member.bio}
                </p>
              </div>

              <div className="pt-2.5 border-t border-slate-100 flex flex-wrap gap-1">
                {member.expertise.map((exp) => (
                  <span
                    key={exp}
                    className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium"
                  >
                    {exp}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Values Section */}
      <div className="space-y-4">
        <div className="max-w-xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-display">
            Guiding Principles
          </span>
          <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
            Our Core Values
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {CORE_VALUES.map((val, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_6px_20px_-4px_rgba(15,23,42,0.05)] space-y-1.5"
            >
              <div className="w-6 h-6 rounded-md bg-emerald-50 text-[#047857] flex items-center justify-center font-bold text-xs">
                0{idx + 1}
              </div>
              <h3 className="text-sm sm:text-base font-display font-bold text-[#0A192F]">
                {val.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {val.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="bg-[#0A192F] rounded-2xl p-6 sm:p-8 text-white text-center space-y-2.5">
        <h2 className="text-lg sm:text-xl font-display font-bold">
          Let’s discuss what makes sense for your business.
        </h2>
        <p className="text-slate-300 text-xs max-w-lg mx-auto">
          Book a free 25-minute consultation with our founders. No pressure, no obligations.
        </p>
        <div className="pt-2">
          <button
            onClick={onOpenConsultation}
            className="px-5 py-2.5 rounded-full bg-[#00D29E] text-[#0A192F] font-display font-bold text-xs hover:bg-[#00e8af] transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <span>Book a Free Consultation</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
