import React from 'react';
import { PageId } from '../types';
import { BRAND_CONFIG } from '../data/config';
import { ShieldCheck, ArrowLeft } from 'lucide-react';

interface TermsPageProps {
  onNavigate: (page: PageId) => void;
}

export const TermsPage: React.FC<TermsPageProps> = ({ onNavigate }) => {
  return (
    <div className="pt-20 sm:pt-24 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-14" id="terms-page-container">
      <div>
        <button
          onClick={() => onNavigate('home')}
          className="text-xs font-semibold text-slate-500 hover:text-slate-900 inline-flex items-center gap-1 mb-3 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Home</span>
        </button>

        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-semibold uppercase tracking-wide mb-2">
          <ShieldCheck className="w-3 h-3 text-[#00D29E]" />
          <span>Legal & Terms</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-display font-bold text-[#0A192F]">
          Terms of Service
        </h1>
        <p className="text-[11px] text-slate-500 mt-0.5">
          Last Updated: August 2026 • WebMint Digital
        </p>
      </div>

      <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] space-y-5 text-xs text-slate-700 leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            1. Agreement to Terms
          </h2>
          <p>
            By accessing or using the WebMint website (webmint.in) or booking a digital consultation with our team, you agree to be bound by these Terms of Service.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            2. Scope of Services & Consultations
          </h2>
          <p>
            WebMint provides website strategy, UI/UX design, modern React web development, and workflow automation services.
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600">
            <li><strong>Free Consultation:</strong> Our introductory 25-minute consultation is completely free of charge and carries zero purchase obligation.</li>
            <li><strong>Pricing Tiers & Proposals:</strong> Package starting prices (e.g. ₹11,500 Starter, ₹17,500 Growth, ₹22,999 Premium) serve as transparent baseline guidelines. Specific project scopes, timelines, and milestones are confirmed in writing prior to commencing any development work.</li>
            <li><strong>No Guaranteed Outcomes:</strong> While we build robust technical foundations adhering to web standards, we do not claim guaranteed search engine rankings, specific traffic figures, or fixed conversion percentages.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            3. Client Asset Ownership
          </h2>
          <p>
            We believe clients should always maintain sovereign ownership over their digital infrastructure. All domain names, hosting accounts, and third-party SaaS tool subscriptions remain 100% in your name. Upon project completion and final settlement, all custom frontend code and tailored automation workflows are handed over to you.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            4. Contact
          </h2>
          <p>
            For any contractual questions or inquiries regarding our terms, please contact us at{' '}
            <a href={`mailto:${BRAND_CONFIG.contactEmail}`} className="text-[#047857] font-semibold underline">
              {BRAND_CONFIG.contactEmail}
            </a>
            .
          </p>
        </section>
      </div>
    </div>
  );
};
