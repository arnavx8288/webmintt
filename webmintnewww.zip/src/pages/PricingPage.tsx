import React from 'react';
import { PageId } from '../types';
import { PRICING_PACKAGES, BRAND_CONFIG } from '../data/config';
import { Check, ArrowRight, ShieldCheck, HelpCircle, Sparkles, MessageSquare } from 'lucide-react';

interface PricingPageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: (packageId?: string) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 sm:space-y-10 pb-14" id="pricing-page-container">
      {/* Header */}
      <div className="max-w-2xl text-center mx-auto space-y-2.5">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold uppercase tracking-wide">
          <ShieldCheck className="w-3 h-3 text-[#00D29E]" />
          <span>Transparent Starting Scope</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
          Clear, honest pricing with zero hidden surprises.
        </h1>

        <p className="text-slate-600 text-xs sm:text-sm leading-relaxed max-w-xl mx-auto">
          These packages serve as transparent starting foundations. During your free consultation, we confirm your exact scope so you only pay for what actually serves your business goals.
        </p>

        <p className="text-[11px] text-slate-400">
          All prices in INR ({BRAND_CONFIG.currency}). International quotes (USD / EUR / GBP) available upon request.
        </p>
      </div>

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-5 items-stretch">
        {PRICING_PACKAGES.map((tier) => (
          <div
            key={tier.id}
            id={`pricing-card-${tier.id}`}
            className={`rounded-2xl p-5 sm:p-6 transition-all flex flex-col justify-between relative ${
              tier.isPopular
                ? 'bg-[#0A192F] text-white shadow-lg ring-2 ring-[#00D29E]'
                : 'bg-white text-[#0F172A] shadow-[0_8px_25px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_12px_32px_-4px_rgba(15,23,42,0.09)]'
            }`}
          >
            {tier.isPopular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#00D29E] text-[#0A192F] text-[10px] font-bold uppercase tracking-wider px-3 py-0.5 rounded-full shadow-2xs">
                Most Popular Choice
              </div>
            )}

            <div>
              {/* Header Info */}
              <div className="mb-3">
                <h3 className={`text-base sm:text-lg font-display font-bold mb-1 ${tier.isPopular ? 'text-white' : 'text-[#0A192F]'}`}>
                  {tier.name}
                </h3>
                <p className={`text-xs leading-relaxed ${tier.isPopular ? 'text-slate-300' : 'text-slate-500'}`}>
                  {tier.tagline}
                </p>
              </div>

              {/* Price */}
              <div className="mb-3 pb-3 border-b border-slate-200/30">
                <div className="flex items-baseline gap-1">
                  <span className={`text-2xl sm:text-3xl font-display font-bold ${tier.isPopular ? 'text-white' : 'text-[#0A192F]'}`}>
                    {tier.priceINR}
                  </span>
                  <span className={`text-xs ${tier.isPopular ? 'text-slate-400' : 'text-slate-500'}`}>
                    / starting price
                  </span>
                </div>
                <p className={`text-[11px] mt-0.5 ${tier.isPopular ? 'text-[#00D29E]' : 'text-slate-500'}`}>
                  {tier.priceNote}
                </p>
              </div>

              {/* Best For */}
              <div className="mb-3">
                <span className={`text-[10px] font-bold uppercase tracking-wider block mb-1 ${tier.isPopular ? 'text-slate-400' : 'text-slate-500'}`}>
                  Best For:
                </span>
                <p className={`text-xs leading-relaxed ${tier.isPopular ? 'text-slate-300' : 'text-slate-600'}`}>
                  {tier.bestFor}
                </p>
              </div>

              {/* What's Included */}
              <div className="space-y-1.5 mb-4">
                <span className={`text-[10px] font-bold uppercase tracking-wider block ${tier.isPopular ? 'text-slate-400' : 'text-slate-500'}`}>
                  What's Included:
                </span>
                <ul className="space-y-1.5 text-xs">
                  {tier.included.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${tier.isPopular ? 'text-[#00D29E]' : 'text-emerald-600'}`} />
                      <span className={tier.isPopular ? 'text-slate-200' : 'text-slate-700'}>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Actions & Scope Disclaimer */}
            <div className="pt-3 border-t border-slate-200/20 space-y-2">
              <p className="text-[11px] leading-relaxed italic text-slate-400">
                {tier.scopeNote}
              </p>

              <button
                type="button"
                id={`btn-pricing-${tier.id}`}
                onClick={() => onOpenConsultation(tier.name)}
                className={`w-full py-2 px-3 rounded-xl font-display font-semibold text-xs transition-all flex items-center justify-center gap-1 cursor-pointer shadow-2xs ${
                  tier.isPopular
                    ? 'bg-[#00D29E] text-[#0A192F] hover:bg-[#00e8af]'
                    : 'bg-[#0A192F] text-white hover:bg-slate-800'
                }`}
              >
                <span>{tier.ctaText}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Custom Scope / Automation Callout Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] text-center max-w-2xl mx-auto space-y-3">
        <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
          Need automation, a custom web app, integrations, or a different scope?
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm max-w-lg mx-auto leading-relaxed">
          Let’s discuss what will actually help your business. We provide custom proposals for complex operational workflows, dynamic portals, and multi-tool automations.
        </p>
        <div className="pt-1">
          <button
            onClick={() => onOpenConsultation('Custom Scope')}
            className="px-4 py-2 rounded-full bg-[#0A192F] text-white font-display font-semibold text-xs hover:bg-slate-800 transition-all inline-flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <MessageSquare className="w-3 h-3 text-[#00D29E]" />
            <span>Get a Free Consultation</span>
          </button>
        </div>
      </div>

      {/* Transparency Note regarding Domain & Hosting */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_6px_20px_-3px_rgba(15,23,42,0.05)] max-w-2xl mx-auto text-xs text-slate-600 space-y-1.5">
        <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-800 font-display flex items-center gap-1.5">
          <HelpCircle className="w-3.5 h-3.5 text-[#00D29E]" />
          <span>Our Transparency & Ownership Policy</span>
        </h4>
        <p className="leading-relaxed text-xs">
          <strong>100% Asset Ownership:</strong> To protect your business, domain registration and hosting services remain 100% in your name. We never mark up third-party services or lock you into proprietary hosting contracts. We will guide you through connecting them seamlessly.
        </p>
        <p className="leading-relaxed text-[11px] text-slate-500">
          Third-party service fees (such as domain registration ~₹800-1200/yr or specialized SMS/CRM API fees) are paid directly by you to the provider without markup.
        </p>
      </div>
    </div>
  );
};
