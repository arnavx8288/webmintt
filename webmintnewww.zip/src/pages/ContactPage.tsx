import React from 'react';
import { PageId } from '../types';
import { ConsultationForm } from '../components/ConsultationForm';
import { BRAND_CONFIG } from '../data/config';
import { Mail, Instagram, Clock, ShieldCheck, HelpCircle, ArrowRight, MessageCircle, Phone, Calendar, ArrowUpRight } from 'lucide-react';

interface ContactPageProps {
  initialHelpType?: 'Website' | 'Automation' | 'Both' | 'Not sure yet';
  initialNotes?: string;
  onNavigate: (page: PageId) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  initialHelpType = 'Not sure yet',
  initialNotes = '',
  onNavigate,
}) => {
  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-14" id="contact-page-container">
      {/* Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start">
        {/* Left Column: Context & Contact Details */}
        <div className="lg:col-span-5 space-y-4">
          <div className="space-y-2.5">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold uppercase tracking-wide">
              <ShieldCheck className="w-3 h-3 text-[#00D29E]" />
              <span>Free Consultation</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
              Let’s discuss your business.
            </h1>

            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Tell us about your business goals and what current challenges you face. We’ll help you understand whether a website, automation, or another next step makes sense.
            </p>
          </div>

          {/* Quick Schedule via Calendly Option */}
          <a
            id="contact-calendly-card-btn"
            href={BRAND_CONFIG.calendlyUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="block p-4 rounded-2xl bg-gradient-to-br from-[#0A192F] to-[#142A4A] text-white shadow-xs hover:shadow-md transition-all group border border-slate-700 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#00D29E]/20 text-[#00D29E] flex items-center justify-center">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-semibold flex items-center gap-1 text-white">
                    <span>Instant Booking via Calendly</span>
                    <span className="text-[9px] bg-[#00D29E] text-[#0A192F] px-1 py-0.5 rounded font-bold uppercase">25 min</span>
                  </div>
                  <p className="text-[11px] text-slate-300">Pick a convenient Google Meet slot directly</p>
                </div>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#00D29E] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
          </a>

          {/* Direct channels */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] space-y-3">
            <h3 className="text-sm sm:text-base font-display font-bold text-[#0A192F]">
              Reach Out Directly
            </h3>
            
            <div className="flex flex-col gap-1.5 text-xs">
              <a
                href={BRAND_CONFIG.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-emerald-50 text-slate-800 hover:text-emerald-700 transition-colors font-medium cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-3.5 h-3.5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] font-semibold">WhatsApp & Call</span>
                  <span className="text-[11px] text-slate-600">{BRAND_CONFIG.phoneNumber}</span>
                </div>
              </a>

              <a
                href={`mailto:${BRAND_CONFIG.contactEmail}`}
                className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-50 text-slate-800 hover:text-[#047857] transition-colors font-medium cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-slate-100 text-[#0A192F] flex items-center justify-center shrink-0">
                  <Mail className="w-3.5 h-3.5 text-[#00D29E]" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] font-semibold">Official Email</span>
                  <span className="text-[11px] text-slate-600">{BRAND_CONFIG.contactEmail}</span>
                </div>
              </a>

              <a
                href={BRAND_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-50 text-slate-800 hover:text-[#047857] transition-colors font-medium cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-slate-100 text-[#0A192F] flex items-center justify-center shrink-0">
                  <Instagram className="w-3.5 h-3.5 text-[#00D29E]" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] font-semibold">Instagram</span>
                  <span className="text-[11px] text-slate-600">{BRAND_CONFIG.instagramHandle}</span>
                </div>
              </a>
            </div>

            <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-100">
              Location: {BRAND_CONFIG.primaryLocation}
            </p>
          </div>

          {/* Quick info boxes */}
          <div className="space-y-2 text-xs">
            <div className="bg-white rounded-xl p-3 sm:p-3.5 shadow-[0_4px_16px_-3px_rgba(15,23,42,0.04)] flex items-start gap-2">
              <Clock className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 block font-semibold text-[11px]">25-Minute Discovery Call</strong>
                <span className="text-slate-600 text-[11px]">Conducted via Google Meet or phone. Relaxed, focused on your business, zero pressure.</span>
              </div>
            </div>

            <div className="bg-white rounded-xl p-3 sm:p-3.5 shadow-[0_4px_16px_-3px_rgba(15,23,42,0.04)] flex items-start gap-2">
              <HelpCircle className="w-3.5 h-3.5 text-[#00D29E] shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 block font-semibold text-[11px]">Honest Recommendations</strong>
                <span className="text-slate-600 text-[11px]">If you don't need a website or automation right now, we will be the first to tell you candidly.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Full Interactive Consultation Form */}
        <div className="lg:col-span-7">
          <ConsultationForm
            initialHelpType={initialHelpType}
            initialNotes={initialNotes}
            onViewPrivacy={() => onNavigate('privacy')}
          />
        </div>
      </div>
    </div>
  );
};
