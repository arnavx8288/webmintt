import React from 'react';
import { PageId } from '../types';
import { BRAND_CONFIG } from '../data/config';
import { ShieldCheck, ArrowLeft } from 'lucide-react';

interface PrivacyPageProps {
  onNavigate: (page: PageId) => void;
}

export const PrivacyPage: React.FC<PrivacyPageProps> = ({ onNavigate }) => {
  return (
    <div className="pt-20 sm:pt-24 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-14" id="privacy-page-container">
      <div>
        <button
          onClick={() => onNavigate('home')}
          className="text-xs font-semibold text-slate-500 hover:text-slate-900 inline-flex items-center gap-1 mb-3 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Home</span>
        </button>

        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-semibold uppercase tracking-wide mb-2">
          <ShieldCheck className="w-3 h-3 text-[#00D29E]" />
          <span>Legal & Privacy</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-display font-bold text-[#0A192F]">
          Privacy Policy
        </h1>
        <p className="text-[11px] text-slate-500 mt-0.5">
          Last Updated: August 2026 • WebMint Digital
        </p>
      </div>

      <div className="bg-white rounded-2xl p-5 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] space-y-5 text-xs text-slate-700 leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            1. Overview & Commitment
          </h2>
          <p>
            At WebMint ({BRAND_CONFIG.name}), we value the trust you place in us when sharing details about your business. This Privacy Policy explains what information we collect when you visit our website or submit a consultation request, how we use it, and how we protect your privacy.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            2. Information We Collect
          </h2>
          <p>
            We only collect information that you explicitly provide to us through our consultation forms, direct email communications, or messaging channels. This typically includes:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600">
            <li>Your name and business name</li>
            <li>Contact details such as email address and phone or WhatsApp number</li>
            <li>Country or geographic location</li>
            <li>Existing website URL or social media links</li>
            <li>Business goals, operational challenges, and preferred contact methods</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            3. How We Use Your Information
          </h2>
          <p>
            We use the details you provide exclusively to:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600">
            <li>Review your business context before our scheduled consultation call</li>
            <li>Communicate with you regarding your inquiry, proposals, or project deliverables</li>
            <li>Provide tailored recommendations and scope estimations</li>
          </ul>
          <p className="font-semibold text-slate-900">
            We will never sell, rent, trade, or distribute your personal or business data to third-party advertisers or data brokers.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            4. Analytics & Cookies
          </h2>
          <p>
            Our website may use standard analytics services (e.g. privacy-conscious telemetry) solely to monitor aggregate site performance, page load speeds, and error diagnostics. We do not engage in invasive cross-site tracking.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-display font-bold text-[#0A192F]">
            5. Contact Us Regarding Your Data
          </h2>
          <p>
            If you wish to access, update, or delete any personal information submitted to WebMint, please reach out directly at{' '}
            <a href={`mailto:${BRAND_CONFIG.contactEmail}`} className="text-[#047857] font-semibold underline">
              {BRAND_CONFIG.contactEmail}
            </a>
            . We will promptly fulfill your request.
          </p>
        </section>
      </div>
    </div>
  );
};
