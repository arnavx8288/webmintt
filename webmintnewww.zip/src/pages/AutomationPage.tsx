import React from 'react';
import { PageId } from '../types';
import { SERVICES_LIST } from '../data/config';
import { Cpu, ArrowRight, CheckCircle2, XCircle, Zap, Clock, ShieldCheck, Database, MessageSquare } from 'lucide-react';

interface AutomationPageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: (type?: 'Automation') => void;
}

export const AutomationPage: React.FC<AutomationPageProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  const service = SERVICES_LIST.find((s) => s.id === 'automation')!;

  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 pb-14" id="automation-page-container">
      {/* Hero */}
      <div className="max-w-2xl space-y-2.5">
        <button
          onClick={() => onNavigate('services')}
          className="text-xs font-semibold text-slate-500 hover:text-slate-900 inline-flex items-center gap-1 mb-0.5 cursor-pointer"
        >
          <span>← Back to Services</span>
        </button>

        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800 text-[10px] font-semibold uppercase tracking-wide">
          <Cpu className="w-3 h-3 text-[#00D29E]" />
          <span>Workflow Automation</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
          Practical automations that save real hours, not hype.
        </h1>

        <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
          Most small businesses don't need complex enterprise AI bots. They need simple, rock-solid connections between their website forms, inboxes, WhatsApp, spreadsheets, and calendar tools so leads are never lost and repetitive tasks disappear.
        </p>

        <div className="pt-1 flex flex-wrap items-center gap-3">
          <button
            onClick={() => onOpenConsultation('Automation')}
            className="px-4 py-2 rounded-full bg-[#0A192F] text-white font-display font-semibold text-xs hover:bg-[#132845] transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
          >
            <span>Book Automation Consultation</span>
            <ArrowRight className="w-3 h-3 text-[#00D29E]" />
          </button>
        </div>
      </div>

      {/* Practical Automation Examples Grid */}
      <div className="space-y-4">
        <div className="max-w-xl">
          <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F] mb-1">
            Real Workflow Examples We Implement
          </h2>
          <p className="text-slate-600 text-xs">
            Step 1 is always mapping out how your team currently spends their time manually.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {service.capabilities.map((cap, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_8px_25px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_12px_30px_-4px_rgba(15,23,42,0.09)] transition-all flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-bold text-[#00D29E] font-mono block mb-1">
                  System 0{idx + 1}
                </span>
                <h3 className="text-sm sm:text-base font-display font-bold text-[#0A192F] mb-1">
                  {cap.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {cap.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Before vs After Scenario */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-7 shadow-lg space-y-4">
        <div className="max-w-xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#00D29E] font-display block mb-0.5">
            Real-World Impact
          </span>
          <h3 className="text-lg sm:text-xl font-display font-bold">
            How a Practical Automation Transforms Your Day
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-800/80 p-4 rounded-xl shadow-inner space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 font-mono">
              Before (Manual Chaos)
            </span>
            <p className="text-xs text-slate-300 leading-relaxed">
              A potential client fills out a website form. The inquiry sits in an unmonitored mailbox for 6 hours. Someone eventually sees it, manually types the details into an Excel sheet, messages a team member on WhatsApp, and sends a late email reply after the prospect has already moved on.
            </p>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-xl shadow-inner space-y-2 ring-1 ring-emerald-500/30">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#00D29E] font-mono">
              After (WebMint Automated System)
            </span>
            <p className="text-xs text-slate-300 leading-relaxed">
              The client submits the form. In under 2 seconds: an automated summary pings the assigned team member on Slack/WhatsApp, the contact is synced into Google Sheets, and the client receives a warm acknowledgment email with a direct booking link.
            </p>
          </div>
        </div>
      </div>

      {/* Expectation Standards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-emerald-50/70 rounded-2xl p-5 shadow-2xs">
          <h3 className="text-base font-display font-bold text-[#064E3B] mb-2.5 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#00D29E]" />
            <span>What We Deliver</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-700">
            {service.whatToExpect.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-[#00D29E] font-bold mt-0.5">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-rose-50/60 rounded-2xl p-5 shadow-2xs">
          <h3 className="text-base font-display font-bold text-[#881337] mb-2.5 flex items-center gap-1.5">
            <XCircle className="w-4 h-4 text-rose-500" />
            <span>What We Avoid</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-700">
            {service.whatWeAvoid.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-rose-400 font-bold mt-0.5">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="bg-[#0A192F] rounded-2xl p-6 sm:p-8 text-white text-center space-y-3">
        <h3 className="text-lg sm:text-xl font-display font-bold">
          Want to eliminate repetitive operational bottlenecks?
        </h3>
        <p className="text-slate-300 text-xs max-w-lg mx-auto">
          We’ll review your existing tools and show you exactly what can be automated cleanly.
        </p>
        <button
          onClick={() => onOpenConsultation('Automation')}
          className="px-5 py-2.5 rounded-full bg-[#00D29E] text-[#0A192F] font-display font-bold text-xs hover:bg-[#00e8af] transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
        >
          <span>Book an Automation Discovery</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
