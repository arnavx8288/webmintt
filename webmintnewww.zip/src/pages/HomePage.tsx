import React, { useState } from 'react';
import { PageId } from '../types';
import {
  BRAND_CONFIG,
  SERVICES_LIST,
  PROCESS_STEPS,
  WHY_WEBMINT_POINTS,
  PORTFOLIO_ITEMS,
  FAQS
} from '../data/config';
import { DigitalScoper } from '../components/DigitalScoper';
import {
  ArrowRight,
  Globe,
  Cpu,
  MessageSquare,
  CheckCircle2,
  XCircle,
  Clock,
  Instagram,
  ShieldCheck,
  Zap,
  ChevronDown,
  Layers,
  Sparkles,
  Smartphone,
  Check
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultationWithPreset?: (type?: 'Website' | 'Automation' | 'Both' | 'Not sure yet', notes?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenConsultationWithPreset,
}) => {
  const [activeTab, setActiveTab] = useState<'website' | 'automation' | 'both'>('website');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const handleOpenConsultation = (type?: 'Website' | 'Automation' | 'Both' | 'Not sure yet', notes?: string) => {
    if (onOpenConsultationWithPreset) {
      onOpenConsultationWithPreset(type, notes);
    } else {
      onNavigate('contact');
    }
  };

  return (
    <div className="space-y-12 sm:space-y-16 lg:space-y-20 pb-12" id="home-page-container">
      {/* 1. HERO SECTION */}
      <section className="pt-16 sm:pt-20 lg:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          {/* Left Column: Copy & CTAs */}
          <div className="lg:col-span-7 space-y-4 text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100/90 border border-slate-200/80 text-slate-700 text-[10px] font-semibold tracking-wide uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D29E] animate-pulse" />
              <span>Modern Websites & Practical Automation</span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-[42px] font-display font-bold text-[#0A192F] leading-[1.14] tracking-tight">
              Your business doesn’t need <span className="text-slate-400 font-normal">“just a website.”</span> It needs the <span className="text-[#0A192F] underline decoration-[#00D29E] decoration-4 underline-offset-4">right digital system.</span>
            </h1>

            <p className="text-slate-600 text-xs sm:text-sm md:text-base leading-relaxed max-w-xl">
              WebMint helps businesses understand what will actually move them forward—then builds fast, modern websites and smart automations that are made around their goals.
            </p>

            {/* CTAs */}
            <div className="pt-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
              <button
                id="hero-primary-cta"
                onClick={() => handleOpenConsultation('Not sure yet')}
                className="px-4 py-2.5 rounded-full bg-[#0A192F] text-white font-display font-semibold text-xs hover:bg-[#132845] active:scale-[0.98] transition-all shadow-xs flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>Book a Free Consultation</span>
                <ArrowRight className="w-3 h-3 text-[#00D29E] transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              <button
                id="hero-secondary-cta"
                onClick={() => onNavigate('services')}
                className="px-4 py-2.5 rounded-full bg-white text-slate-800 font-display font-semibold text-xs border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-all flex items-center justify-center cursor-pointer shadow-2xs"
              >
                <span>Explore Services</span>
              </button>
            </div>

            {/* Reassurances */}
            <div className="pt-1 flex flex-wrap items-center gap-y-1.5 gap-x-4 text-[10px] sm:text-[11px] text-slate-500">
              <div className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-[#00D29E]" />
                <span>Zero pushy sales pitch</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-[#00D29E]" />
                <span>Starting from ₹11,500</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-[#00D29E]" />
                <span>Indian & global clients</span>
              </div>
            </div>
          </div>

          {/* Right Column: Refined Interactive System Architecture Visual */}
          <div className="lg:col-span-5">
            <div className="bg-gradient-to-b from-[#0A192F] to-[#0d1e38] rounded-2xl p-4 sm:p-5 text-white shadow-lg border border-slate-800 relative overflow-hidden">
              {/* Top Bar with System Controls */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 rounded-full bg-rose-500/80" />
                    <span className="w-2 h-2 rounded-full bg-amber-500/80" />
                    <span className="w-2 h-2 rounded-full bg-emerald-500/80" />
                  </div>
                  <span className="font-mono text-slate-400 text-[10px] ml-1">webmint.system</span>
                </div>
                <span className="text-[9px] font-mono uppercase text-[#00D29E] bg-[#00D29E]/10 px-2 py-0.5 rounded-full font-semibold">
                  Live Flow
                </span>
              </div>

              {/* Interactive Segment Toggles */}
              <div className="mt-2.5 grid grid-cols-3 gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveTab('website')}
                  className={`py-1 rounded-lg font-medium transition-all text-center text-[10px] ${
                    activeTab === 'website'
                      ? 'bg-[#00D29E] text-[#0A192F] font-bold shadow-2xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  1. Website
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('automation')}
                  className={`py-1 rounded-lg font-medium transition-all text-center text-[10px] ${
                    activeTab === 'automation'
                      ? 'bg-[#00D29E] text-[#0A192F] font-bold shadow-2xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  2. Automation
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('both')}
                  className={`py-1 rounded-lg font-medium transition-all text-center text-[10px] ${
                    activeTab === 'both'
                      ? 'bg-[#00D29E] text-[#0A192F] font-bold shadow-2xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  3. Connected
                </button>
              </div>

              {/* Visual Body based on activeTab */}
              <div className="mt-3 min-h-[160px] flex flex-col justify-between">
                {activeTab === 'website' && (
                  <div className="space-y-2 animate-in fade-in duration-200">
                    <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700/60">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                          <Smartphone className="w-3.5 h-3.5 text-[#00D29E]" />
                          Mobile-First Discovery
                        </span>
                        <span className="text-[9px] text-emerald-400 font-mono">Fast &lt;1.2s</span>
                      </div>
                      <p className="text-[10px] text-slate-300 leading-relaxed">
                        Customers view services, proof & trust signals cleanly on mobile devices.
                      </p>
                    </div>
                    <div className="flex items-center justify-center text-slate-500 text-[10px]">
                      <span>↓ Direct inquiry trigger</span>
                    </div>
                    <div className="bg-slate-800/50 rounded-xl p-2.5 border border-slate-700/40 flex items-center justify-between text-xs">
                      <span className="text-slate-300 text-[10px]">WhatsApp / Booking Trigger</span>
                      <span className="text-[#00D29E] font-medium font-mono text-[10px]">100% Frictionless</span>
                    </div>
                  </div>
                )}

                {activeTab === 'automation' && (
                  <div className="space-y-2 animate-in fade-in duration-200">
                    <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700/60">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                          <Zap className="w-3.5 h-3.5 text-[#00D29E]" />
                          Automated Lead Triage
                        </span>
                        <span className="text-[9px] text-emerald-400 font-mono">Instant 0s</span>
                      </div>
                      <p className="text-[10px] text-slate-300 leading-relaxed">
                        Form inquiry routes instantly to your Slack, Email, or CRM + auto-confirms receipt.
                      </p>
                    </div>
                    <div className="flex items-center justify-center text-slate-500 text-[10px]">
                      <span>↓ Zero manual copying</span>
                    </div>
                    <div className="bg-slate-800/50 rounded-xl p-2.5 border border-slate-700/40 flex items-center justify-between text-xs">
                      <span className="text-slate-300 text-[10px]">Google Sheets / CRM Sync</span>
                      <span className="text-[#00D29E] font-medium font-mono text-[10px]">Auto-logged</span>
                    </div>
                  </div>
                )}

                {activeTab === 'both' && (
                  <div className="space-y-1.5 animate-in fade-in duration-200">
                    <div className="bg-slate-800/80 rounded-xl p-2.5 border border-slate-700/60 flex items-center justify-between text-xs">
                      <span className="text-white font-medium text-[10px]">1. Fast React Frontend</span>
                      <span className="text-[#00D29E] text-[9px] font-mono">Builds Trust</span>
                    </div>
                    <div className="flex items-center justify-center text-slate-500 text-[9px]">
                      <span>↓ Webhook Trigger</span>
                    </div>
                    <div className="bg-slate-800/80 rounded-xl p-2.5 border border-slate-700/60 flex items-center justify-between text-xs">
                      <span className="text-white font-medium text-[10px]">2. Automated Triage & Calendar</span>
                      <span className="text-[#00D29E] text-[9px] font-mono">Saves 8+ hrs</span>
                    </div>
                    <div className="flex items-center justify-center text-slate-500 text-[9px]">
                      <span>↓ Real-time notification</span>
                    </div>
                    <div className="bg-slate-800/80 rounded-xl p-2.5 border border-slate-700/60 flex items-center justify-between text-xs">
                      <span className="text-white font-medium text-[10px]">3. Closed Client / Order</span>
                      <span className="text-emerald-400 text-[9px] font-mono">High ROI</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Card Footer */}
              <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                <span>Tailored for your business</span>
                <button
                  type="button"
                  onClick={() => handleOpenConsultation(activeTab === 'both' ? 'Both' : activeTab === 'website' ? 'Website' : 'Automation')}
                  className="text-[#00D29E] hover:underline font-medium inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Build this system</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. PROBLEM / DIFFERENTIATION SECTION */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" id="problem-differentiation-section">
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5 font-display">
            The Industry Reality
          </span>
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-display font-bold text-[#0A192F] mb-2">
            Cheap websites are easy. Useful digital systems are harder.
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
            Many low-cost agencies deliver slow, generic templates. WebMint takes a thoughtful, business-first approach that saves time and generates trust.
          </p>
        </div>

        {/* Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6">
          {/* Typical Quick-Build Agency */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] relative">
            <div className="flex items-center gap-2 mb-4">
              <span className="w-2 h-2 rounded-full bg-slate-300" />
              <h3 className="text-base sm:text-lg font-display font-bold text-slate-700">
                Typical Quick-Build Website
              </h3>
            </div>

            <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
              <li className="flex items-start gap-2.5">
                <XCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-800 font-semibold block text-xs sm:text-sm">Template-first assembly</strong>
                  <span className="text-xs text-slate-500">Rigid templates identical to hundreds of other websites.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <XCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-800 font-semibold block text-xs sm:text-sm">Standard commodities as "breakthroughs"</strong>
                  <span className="text-xs text-slate-500">Pitching SSL or forms without understanding your workflow.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <XCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-800 font-semibold block text-xs sm:text-sm">Slow on mobile devices</strong>
                  <span className="text-xs text-slate-500">Sluggish loading on mobile networks where customers evaluate you.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <XCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-800 font-semibold block text-xs sm:text-sm">Zero operational support</strong>
                  <span className="text-xs text-slate-500">Still manually copying leads and replying to DMs for hours.</span>
                </div>
              </li>
            </ul>
          </div>

          {/* WebMint Approach */}
          <div className="bg-[#0A192F] text-white rounded-2xl p-5 sm:p-6 shadow-[0_10px_35px_-5px_rgba(10,25,47,0.25)] relative">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#00D29E]" />
                <h3 className="text-base sm:text-lg font-display font-bold text-white">
                  The WebMint Approach
                </h3>
              </div>
              <span className="text-[9px] font-mono text-[#00D29E] bg-[#00D29E]/10 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold">
                Business-First
              </span>
            </div>

            <ul className="space-y-3 text-xs sm:text-sm text-slate-300">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#00D29E] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white font-semibold block text-xs sm:text-sm">Discovery before code</strong>
                  <span className="text-xs text-slate-300">We understand your operations, growth goals, and customer priorities first.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#00D29E] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white font-semibold block text-xs sm:text-sm">Modern React development</strong>
                  <span className="text-xs text-slate-300">Fast, custom layouts built around credibility and conversion.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#00D29E] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white font-semibold block text-xs sm:text-sm">High-speed mobile performance</strong>
                  <span className="text-xs text-slate-300">Clean codebases optimized for rapid loading and SEO.</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#00D29E] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white font-semibold block text-xs sm:text-sm">Practical workflow automation</strong>
                  <span className="text-xs text-slate-300">Connecting your web presence to time-saving automations.</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* 3. SERVICES OVERVIEW */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" id="services-overview-section">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 sm:mb-8 gap-2">
          <div className="max-w-xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-display">
              What We Build
            </span>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-display font-bold text-[#0A192F]">
              Three clear capabilities tailored to your goals.
            </h2>
          </div>

          <button
            onClick={() => onNavigate('services')}
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#0A192F] hover:text-[#047857] transition-colors cursor-pointer"
          >
            <span>View all capabilities</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5">
          {SERVICES_LIST.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-2xl p-5 sm:p-6 shadow-[0_8px_25px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_14px_30px_-4px_rgba(15,23,42,0.09)] transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-[#0A192F] group-hover:bg-[#00D29E]/10 group-hover:text-[#047857] transition-colors">
                    {service.id === 'web-dev' && <Globe className="w-4 h-4" />}
                    {service.id === 'automation' && <Cpu className="w-4 h-4" />}
                    {service.id === 'consultation' && <MessageSquare className="w-4 h-4" />}
                  </div>
                  <span className="text-[9px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                    {service.badge}
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-display font-bold text-[#0A192F] mb-1.5">
                  {service.title}
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed mb-3">
                  {service.shortDesc}
                </p>

                <div className="space-y-1.5 pt-2.5 border-t border-slate-100">
                  {service.capabilities.slice(0, 3).map((cap, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00D29E]" />
                      <span>{cap.title}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onNavigate(service.pageId)}
                  className="text-xs font-semibold text-slate-800 hover:text-[#047857] inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Learn more</span>
                  <ArrowRight className="w-3 h-3" />
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenConsultation(service.id === 'web-dev' ? 'Website' : service.id === 'automation' ? 'Automation' : 'Not sure yet')}
                  className="text-xs font-medium text-slate-500 hover:text-slate-900 cursor-pointer"
                >
                  Book call →
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. PROCESS SECTION */}
      <section className="bg-slate-100/70 py-10 sm:py-14 border-y border-slate-200/60" id="process-section">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-display">
              How We Work
            </span>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-display font-bold text-[#0A192F] mb-2">
              A simple four-step approach to digital clarity.
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm">
              From the initial conversation to launch, you always know what we're building and why.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
            {PROCESS_STEPS.map((step) => (
              <div
                key={step.step}
                className="bg-white rounded-2xl p-4 sm:p-5 shadow-[0_6px_20px_-3px_rgba(15,23,42,0.05),0_2px_6px_-2px_rgba(15,23,42,0.02)] relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xl font-display font-bold text-[#00D29E]">
                      {step.step}
                    </span>
                    <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">
                      {step.name}
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-display font-bold text-[#0A192F] mb-1">
                    {step.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. INTERACTIVE SCOPER & READINESS ASSESSMENT */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <DigitalScoper
          onSelectOption={(type, notes) => handleOpenConsultation(type, notes)}
          onNavigateToPricing={() => onNavigate('pricing')}
        />
      </section>

      {/* 6. WHY WEBMINT */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" id="why-webmint-section">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start">
          <div className="lg:col-span-5 space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block font-display">
              Why Work With Us
            </span>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-display font-bold text-[#0A192F] leading-tight">
              Thoughtful craftsmanship, not commodity checklists.
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              We bridge the gap between creative design, modern web development, and practical back-office automation—backed by an honest conversation before you spend anything.
            </p>
            <div className="pt-1">
              <button
                type="button"
                onClick={() => onNavigate('about')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors cursor-pointer shadow-xs"
              >
                <span>Read our story</span>
                <ArrowRight className="w-3 h-3 text-[#00D29E]" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-2.5">
            {WHY_WEBMINT_POINTS.map((point, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-4 shadow-[0_6px_20px_-3px_rgba(15,23,42,0.05),0_2px_6px_-2px_rgba(15,23,42,0.02)] flex items-start gap-3.5"
              >
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-[#047857] flex items-center justify-center shrink-0 font-bold text-xs mt-0.5">
                  {index + 1}
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-display font-bold text-[#0A192F] mb-0.5">
                    {point.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {point.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. PORTFOLIO PREVIEW */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" id="portfolio-preview-section">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-display">
              Selected Work
            </span>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-display font-bold text-[#0A192F]">
              A look at what WebMint can create
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm mt-0.5">
              Live concepts and architectures crafted with clean aesthetics and conversion intent.
            </p>
          </div>

          <a
            href={BRAND_CONFIG.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors shadow-2xs shrink-0 self-start sm:self-auto cursor-pointer"
          >
            <Instagram className="w-3.5 h-3.5 text-[#00D29E]" />
            <span>See work on Instagram</span>
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
          {PORTFOLIO_ITEMS.slice(0, 2).map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl overflow-hidden shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_14px_35px_-4px_rgba(15,23,42,0.1)] transition-all flex flex-col justify-between"
            >
              {/* Visual Presentation Area */}
              <div className={`h-36 bg-gradient-to-br ${item.gradientTheme} p-4 sm:p-5 flex flex-col justify-between text-white relative overflow-hidden`}>
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-semibold bg-white/20 backdrop-blur-xs px-2 py-0.5 rounded-full text-white">
                    {item.category}
                  </span>
                  <span className="text-[9px] text-slate-300 font-mono">
                    {item.clientType}
                  </span>
                </div>

                <div>
                  <h3 className="text-base sm:text-lg font-display font-bold text-white mb-1">
                    {item.title}
                  </h3>
                  <div className="flex flex-wrap gap-1">
                    {item.tags.map((tag) => (
                      <span key={tag} className="text-[8px] bg-black/30 px-1.5 py-0.5 rounded text-slate-200">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Details */}
              <div className="p-4 sm:p-5 space-y-2.5">
                <p className="text-xs text-slate-600 leading-relaxed">
                  {item.summary}
                </p>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[9px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Key Deliverables:
                  </span>
                  <div className="grid grid-cols-2 gap-1 text-xs text-slate-700">
                    {item.deliverables.map((deliv, idx) => (
                      <div key={idx} className="flex items-center gap-1">
                        <Check className="w-3 h-3 text-[#00D29E] shrink-0" />
                        <span className="truncate text-xs">{deliv}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 text-center">
          <button
            onClick={() => onNavigate('portfolio')}
            className="text-xs font-semibold text-[#0A192F] hover:text-[#047857] underline underline-offset-4 cursor-pointer"
          >
            Explore all portfolio blueprints and design systems →
          </button>
        </div>
      </section>

      {/* 8. FAQS */}
      <section className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8" id="faqs-section">
        <div className="text-center mb-6">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-display">
            Clear Answers
          </span>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-[#0A192F]">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-2.5">
          {FAQS.map((faq, index) => {
            const isOpen = openFaqIndex === index;
            return (
              <div
                key={index}
                className="bg-white rounded-xl shadow-[0_4px_16px_-3px_rgba(15,23,42,0.05)] overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                  className="w-full text-left p-3.5 sm:p-4 flex items-center justify-between gap-2.5 cursor-pointer focus:outline-hidden"
                >
                  <span className="text-xs sm:text-sm font-display font-bold text-[#0A192F]">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 text-slate-500 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-[#00D29E]' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-3.5 sm:px-4 pb-3.5 pt-0 text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                    <p className="pt-2">{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 9. FINAL HIGH-CONVERSION CTA SECTION */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" id="final-cta-section">
        <div className="bg-[#0A192F] rounded-2xl p-6 sm:p-9 text-center text-white relative overflow-hidden shadow-lg border border-slate-800">
          {/* Subtle Background Lighting */}
          <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-[#00D29E]/10 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" />

          <div className="max-w-xl mx-auto relative z-10 space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#00D29E] bg-[#00D29E]/10 px-3 py-0.5 rounded-full inline-block">
              Free 25-Minute Discovery
            </span>

            <h2 className="text-xl sm:text-3xl lg:text-4xl font-display font-bold text-white tracking-tight leading-tight">
              Get clarity before you spend on a website.
            </h2>

            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              Tell us about your business. We’ll help you understand whether a website, automation, or another digital step makes sense.
            </p>

            <div className="pt-1 flex flex-col sm:flex-row items-center justify-center gap-2.5">
              <button
                id="final-section-book-btn"
                onClick={() => handleOpenConsultation('Not sure yet')}
                className="w-full sm:w-auto px-5 py-2.5 rounded-full bg-[#00D29E] text-[#0A192F] font-display font-bold text-xs hover:bg-[#00e8af] active:scale-[0.98] transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Book a Free Consultation</span>
                <ArrowRight className="w-3 h-3" />
              </button>

              <button
                onClick={() => onNavigate('pricing')}
                className="w-full sm:w-auto px-4 py-2.5 rounded-full bg-slate-800 text-slate-200 font-display font-semibold text-xs hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <span>View Transparent Pricing</span>
              </button>
            </div>

            <p className="text-[10px] text-slate-400 pt-0.5">
              No pushy sales • Clear scope guidance • Indian & Global clients
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
