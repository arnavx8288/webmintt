import React, { useState } from 'react';
import { PageId, PortfolioItem } from '../types';
import { PORTFOLIO_ITEMS, BRAND_CONFIG } from '../data/config';
import { Instagram, ArrowRight, ArrowUpRight, Check, Sparkles, Filter } from 'lucide-react';

interface PortfolioPageProps {
  onNavigate: (page: PageId) => void;
  onOpenConsultation: (type?: 'Website' | 'Automation' | 'Both') => void;
}

export const PortfolioPage: React.FC<PortfolioPageProps> = ({
  onNavigate,
  onOpenConsultation,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Website', 'Automation', 'Full Digital System'];

  const filteredItems = selectedCategory === 'All'
    ? PORTFOLIO_ITEMS
    : PORTFOLIO_ITEMS.filter((item) => item.category === selectedCategory);

  return (
    <div className="pt-20 sm:pt-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 sm:space-y-10 pb-14" id="portfolio-page-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="max-w-2xl space-y-2.5">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold uppercase tracking-wide">
            <Sparkles className="w-3 h-3 text-[#00D29E]" />
            <span>Selected Work & Blueprints</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-bold text-[#0A192F] leading-tight">
            A look at what WebMint can create.
          </h1>

          <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
            We believe in complete transparency. Below are representative digital architectures and system flows we design and build. We regularly share live work, design breakdowns, and behind-the-scenes engineering on our Instagram.
          </p>
        </div>

        {/* Prominent Instagram CTA Button */}
        <a
          id="portfolio-hero-instagram-btn"
          href={BRAND_CONFIG.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0A192F] text-white font-display font-semibold text-xs hover:bg-[#132845] transition-all shadow-xs shrink-0 self-start md:self-auto cursor-pointer"
        >
          <Instagram className="w-3.5 h-3.5 text-[#00D29E]" />
          <span>See work on Instagram</span>
          <ArrowUpRight className="w-3 h-3 text-slate-400" />
        </a>
      </div>

      {/* Category Filters */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1.5 flex items-center gap-1">
          <Filter className="w-3 h-3" /> Filter:
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
              selectedCategory === cat
                ? 'bg-[#0A192F] text-white font-semibold shadow-2xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl overflow-hidden shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] hover:shadow-[0_12px_32px_-4px_rgba(15,23,42,0.09)] transition-all flex flex-col justify-between"
          >
            {/* Visual Header / Mockup Banner */}
            <div className={`h-36 sm:h-40 bg-gradient-to-br ${item.gradientTheme} p-4 sm:p-5 flex flex-col justify-between text-white relative`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-semibold bg-white/20 backdrop-blur-xs px-2.5 py-0.5 rounded-full text-white">
                  {item.category}
                </span>
                <span className="text-[11px] text-slate-300 font-mono">
                  {item.clientType}
                </span>
              </div>

              <div>
                <h3 className="text-base sm:text-lg font-display font-bold text-white mb-1">
                  {item.title}
                </h3>
                <div className="flex flex-wrap gap-1">
                  {item.tags.map((tag) => (
                    <span key={tag} className="text-[9px] bg-black/40 px-2 py-0.5 rounded text-slate-200">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Content Details */}
            <div className="p-4 sm:p-5 space-y-3">
              <p className="text-slate-600 text-xs leading-relaxed">
                {item.summary}
              </p>

              <div className="pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5 font-display">
                  System Deliverables:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-700">
                  {item.deliverables.map((deliv, idx) => (
                    <div key={idx} className="flex items-center gap-1.5">
                      <Check className="w-3 h-3 text-[#00D29E] shrink-0" />
                      <span className="truncate">{deliv}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-1 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onOpenConsultation(item.category === 'Website' ? 'Website' : item.category === 'Automation' ? 'Automation' : 'Both')}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#0A192F] hover:text-[#047857] transition-colors cursor-pointer"
                >
                  <span>Build something similar</span>
                  <ArrowRight className="w-3 h-3 text-[#00D29E]" />
                </button>

                {item.isPlaceholder && (
                  <span className="text-[10px] font-mono text-slate-400">
                    * Representative Blueprint
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Instagram Banner Callout */}
      <div className="bg-white rounded-2xl p-6 sm:p-7 shadow-[0_8px_30px_-5px_rgba(15,23,42,0.06),0_2px_8px_-2px_rgba(15,23,42,0.02)] text-center max-w-xl mx-auto space-y-2.5">
        <Instagram className="w-6 h-6 text-[#00D29E] mx-auto" />
        <h2 className="text-lg sm:text-xl font-display font-bold text-[#0A192F]">
          Follow our latest case studies and live walkthroughs
        </h2>
        <p className="text-slate-600 text-xs leading-relaxed">
          We post breakdowns of website speed tests, conversion layouts, and automation recipes on our Instagram account.
        </p>
        <div className="pt-1">
          <a
            href={BRAND_CONFIG.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0A192F] text-white text-xs font-semibold hover:bg-slate-800 transition-colors shadow-2xs cursor-pointer"
          >
            <span>Visit {BRAND_CONFIG.instagramHandle}</span>
            <ArrowUpRight className="w-3 h-3 text-[#00D29E]" />
          </a>
        </div>
      </div>
    </div>
  );
};
